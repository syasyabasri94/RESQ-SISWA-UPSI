<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/login.html");
    exit();
}

// Database connection settings
require '../mysqlconnection.php';
include 'layout/header.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the staff ID from the session
$staff_id = $_SESSION['staff_id'];

// Get the hostel ID from the URL parameter
if (isset($_GET['hostel_id'])) {
    $hostel_id = intval($_GET['hostel_id']);

    // Check if the staff member already has a hostel assigned
    $sql = "SELECT hostel_id FROM staff WHERE staff_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $stmt->bind_result($assigned_hostel_id);
    $stmt->fetch();
    $stmt->close();

    if ($assigned_hostel_id) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Hostel Already Assigned',
                text: 'You have already been assigned to a hostel.',
                confirmButtonText: 'OK',
                allowOutsideClick: false,
                allowEscapeKey: false,
            }).then((result) => {
                window.location.href = 'staffhostel.php';
            });
        </script>";
        exit();
    }

    // Assign the hostel to the staff member
    $sql = "UPDATE staff SET hostel_id = ?,status='PENDING' WHERE staff_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $hostel_id, $staff_id);

    if ($stmt->execute()) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            Swal.fire({
                icon: 'success',
                title: 'Hostel Requested Successfully',
                text: 'You have successfully requested to the hostel.',
                confirmButtonText: 'OK',
                allowOutsideClick: false,
                allowEscapeKey: false,
            }).then((result) => {
                window.location.href = 'staffhostel.php';
            });
        </script>";
    } else {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Assignment Failed',
                text: 'There was a problem assigning the hostel. Please try again.',
                confirmButtonText: 'OK',
                allowOutsideClick: false,
                allowEscapeKey: false,
            }).then((result) => {
                window.location.href = 'staffassignhostel.php';
            });
        </script>";
    }

    $stmt->close();
} else {
    // Redirect if hostel_id is not set
    header("Location: staffassignhostel.php");
    exit();
}

$conn->close();
?>
