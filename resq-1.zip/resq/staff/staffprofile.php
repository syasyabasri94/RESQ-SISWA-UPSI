<?php
session_start();

if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/mainpage.html");
    exit();
}

require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$staffId = $_SESSION['staff_id'];
$sql = "SELECT Name, Phone, Email, Image FROM staff WHERE Staff_ID = $staffId";
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $staffName = htmlspecialchars($row['Name'], ENT_QUOTES, 'UTF-8');
    $staffPhone = htmlspecialchars($row['Phone'], ENT_QUOTES, 'UTF-8');
    $staffEmail = htmlspecialchars($row['Email'], ENT_QUOTES, 'UTF-8');
    $staffImage = $row['Image'];
} else {
    echo "No staff member found with the given ID.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ced3c4;
            color: #fff;
            padding-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
        }
        .sidebar a {
            display: block;
            color: #0c0c0c;
            padding: 10px;
            text-decoration: none;
            text-align: center;
            font-size: 17px;
        }
        .sidebar a:hover {
            background-color: #8f9779;
        }
        .title {
            text-align: center;
            margin-bottom: 20px;
        }
        .profile-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        .profile {
            border: 1px solid #ccc;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            width: 300px;
        }
        .profile h2 {
            margin-top: 0;
            text-align: center;
        }
        .profile img {
            display: block;
            margin: 0 auto 10px;
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile p {
            margin: 5px 0;
            text-align: left;
        }
        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            margin-top: 0px;
        }
        .logo img {
            width: 45px;
            margin-right: 10px;
        }
        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            text-align: center;
            width: 30%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }
        .update-profile-btn {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin-top: 20px;
            cursor: pointer;
            border-radius: 5px;
        }
        .update-profile-btn:hover {
            background-color: #45a049;
        }
        .change-password-container {
            text-align: center;
            margin-top: 40px;
        }
        .change-password-container input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        /* Modal Container */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0,0,0,0.4); /* Black background with opacity */
    transition: opacity 0.3s ease; /* Fade effect */
}

/* Modal Content */
.modal-content {
    background-color: #fff; /* White background */
    margin: 5% auto; /* 5% from top and centered horizontally */
    padding: 20px;
    border: 1px solid #888;
    width: 90%; /* Could be more or less, depends on screen size */
    max-width: 500px; /* Responsive max-width */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0,0,0,0.2); /* Subtle shadow */
    transition: transform 0.3s ease; /* Slide-in effect */
}

/* Close Button */
.close {
    color: #aaa;
    float: right;
    font-size: 24px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

/* Form Elements */
form {
    display: flex;
    flex-direction: column;
}

form label {
    margin-bottom: 5px;
    font-weight: bold;
}

form input[type="text"],
form input[type="email"],
form input[type="file"] {
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

form button {
    background-color: #4CAF50;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

form button:hover {
    background-color: #45a049;
}

    </style>
</head>
<body>
<?php include 'layout/header.php'; ?>
    <div class="content">
        <div class="title">
            <h1>My Profile</h1>
        </div>
        <div class="profile-container">
            <div class="profile">
                <h2><?php echo $staffName; ?></h2>
                <?php
                if ($staffImage) {
                    $imageData = base64_encode($staffImage);
                    echo '<img src="data:image/jpeg;base64,' . $imageData . '" alt="Profile Image">';
                } else {
                    echo '<img src="default-profile.png" alt="Default Profile Image">';
                }
                ?>
                <p><strong>Staff ID:</strong> <?php echo $staffId; ?></p>
                <p><strong>Phone:</strong> <?php echo $staffPhone; ?></p>
                <p><strong>Email:</strong> <?php echo $staffEmail; ?></p>
                <button class="update-profile-btn" onclick="openUpdateProfileModal()">Update Profile</button>
            </div>
        </div>
        <div class="change-password-container">
            <h2>Change Password</h2>
            <form id="changePasswordForm">
                <input type="password" id="oldPassword" placeholder="Old Password" required>
                <input type="password" id="newPassword" placeholder="New Password" required>
                <input type="password" id="confirmPassword" placeholder="Confirm New Password" required>
                <button type="button" onclick="changePassword()">Change Password</button>
            </form>
        </div>
    </div>

    <div id="updateProfileModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeUpdateProfileModal()">&times;</span>
        <h2>Update Profile</h2>
        <form id="updateProfileForm" enctype="multipart/form-data">
            <label for="updateName">Name</label>
            <input type="text" id="updateName" name="name" placeholder="Name" value="<?php echo $staffName; ?>" required>
            
            <label for="updatePhone">Phone</label>
            <input type="text" id="updatePhone" name="phone" placeholder="Phone" value="<?php echo $staffPhone; ?>" required>
            
            <label for="updateEmail">Email</label>
            <input type="email" id="updateEmail" name="email" placeholder="Email" value="<?php echo $staffEmail; ?>" required>
            
            <label for="updateImage">Profile Image</label>
            <input type="file" id="updateImage" name="image" accept="image/*">
            
            <button type="button" onclick="updateProfile()">Update</button>
        </form>
    </div>
</div>


    <div id="changePasswordModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeChangePasswordModal()">&times;</span>
            <p id="modalMessage"></p>
        </div>
    </div>

    <script>
       function openUpdateProfileModal() {
    document.getElementById('updateProfileModal').style.display = 'block';
}

function closeUpdateProfileModal() {
    document.getElementById('updateProfileModal').style.display = 'none';
}

function closeChangePasswordModal() {
    document.getElementById('changePasswordModal').style.display = 'none';
}

function updateProfile() {
    const form = document.getElementById('updateProfileForm');
    const formData = new FormData(form);

    fetch('updateprofile.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showModal(data.message);
        }
    })
    .catch(error => showModal('Error updating profile: ' + error.message));
}

function changePassword() {
    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (newPassword !== confirmPassword) {
        showModal('Passwords do not match.');
        return;
    }

    fetch('change_password.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ oldPassword, newPassword })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Password changed successfully') {
            showModal(data.message, true); // Show success popup
        } else {
            showModal(data.message); // Show error popup
        }
    })
    .catch(error => showModal('Error changing password: ' + error.message));
}

function showModal(message, isSuccess = false) {
    Swal.fire({
        title: isSuccess ? 'Success!' : 'Error!',
        text: message,
        icon: isSuccess ? 'success' : 'error',
        timer: 2000, // Duration in milliseconds
        timerProgressBar: true, // Show progress bar
        didClose: () => {
            // Optional callback when the alert is closed
        }
    });
}


// Close modals when clicking outside of them
window.onclick = function(event) {
    const updateProfileModal = document.getElementById('updateProfileModal');
    const changePasswordModal = document.getElementById('changePasswordModal');

    if (event.target === updateProfileModal) {
        updateProfileModal.style.display = 'none';
    }
    if (event.target === changePasswordModal) {
        changePasswordModal.style.display = 'none';
    }
};

    </script>
</body>
</html>
