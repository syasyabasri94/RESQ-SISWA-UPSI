<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/login.html");
    exit();
}

// Database connection settings
require '../mysqlconnection.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user role from session
$role = $_SESSION['role'];
$staff_id = $_SESSION['staff_id']; // For staff-specific filtering

// Fetch hostel data based on role
if ($role === 'admin') {
    // Admin can view all hostels
    $sql = "SELECT * FROM hostel";
    $result = $conn->query($sql);
} else {
    // Use prepared statement to fetch hostel data for staff
    $stmt = $conn->prepare("SELECT hostel.Hostel_ID, hostel.Name, hostel.Capacity, hostel.Status, hostel.image, hostel.description
                            FROM hostel 
                            JOIN staff ON staff.hostel_id = hostel.Hostel_ID 
                            WHERE staff.staff_id = ?
                            AND staff.status='DONE'");
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

// Check if staff is not assigned to any hostel
if ($result->num_rows == 0) {
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                icon: 'error',
                title: 'Not Assigned to Any Hostel',
                text: 'You need to be assigned to a hostel to proceed.',
                confirmButtonText: 'Assign Now',
                allowOutsideClick: false,
                allowEscapeKey: false,
            }).then((result) => {
                window.location.href = 'staffassignhostel.php';
            });
        });
    </script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Hostel</title>
    <style>
        /* Your existing CSS */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }


        .title {
            text-align: center;
            margin-bottom: 20px;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
        }
        .dashboard-box {
            width: 200px;
            height: 150px;
            background-color: #ced3c4;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
        .dashboard-box:hover {
            background-color: #8f9779;
        }

        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 10px;
            text-align: center;
            width: 30%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }
        .property-list {
            margin-top: 20px;
            width: 100%;
        }
        .property-list-title {
            font-size: 1.8em;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
            margin-right: 65px;
        }
        .properties-table {
            width: 95%;
            border-collapse: collapse;
            margin: right;
        }
        .properties-table th,
        .properties-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .properties-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .properties-table a {
            text-decoration: none;
            color: #007bff;
        }
        .properties-table a:hover {
            color: #0056b3;
        }
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
            font-size: 12px;
        }
        .edit-btn {
            background-color: #4CAF50;
        }
        .edit-btn:hover {
            background-color: #45a049;
        }
        .view-btn {
            background-color: #008CBA;
        }
        .view-btn:hover {
            background-color: #007BB5;
        }
        .delete-btn {
            background-color: #f44336;
        }
        .delete-btn:hover {
            background-color: #d32f2f;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
            padding-top: 50px;
            margin: right;
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 40%;
            text-align: left;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .search-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
            width: 80%;
            margin: 0 auto 20px auto;
        }
        .form-container {
            margin-top: 20px;
            width: 80%;
            margin: 0 auto 20px auto;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
        }
        .hostel-image {
            max-width: 100px;
            height: auto;
        }
    </style>
    <script>
        function viewHostel(id) {
            window.location.href = `view_rooms.php?hostel_id=${id}`;
        }

        function closeModal() {
            document.getElementById('editModal').style.display = "none";
        }

        function editHostel(id, name, capacity, status, image, description) {
            document.getElementById('editHostelId').value = id;
            document.getElementById('editHostelName').value = name;
            document.getElementById('editCapacity').value = capacity;
            document.getElementById('editStatus').value = (status === 'Available' ? 1 : 0);
            document.getElementById('editCurrentImage').src = `data:image/jpeg;base64,${image}`;
            document.getElementById('editDescription').value = description;
            document.getElementById('editModal').style.display = "block";
        }

        function searchHostel() {
            let input = document.getElementById('searchInput').value.toUpperCase();
            let table = document.getElementById('hostelTable');
            let tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                let td = tr[i].getElementsByTagName('td')[1]; // Search in the second column (Hostel Name)
                if (td) {
                    let txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(input) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }

        window.onclick = function(event) {
            if (event.target == document.getElementById('editModal')) {
                closeModal();
            }
        }

    </script>
</head>
<body>
<?php
include 'layout/header.php'; 
?>

<div class="content">
    <div class="title">
        <h2>Hostel Management</h2>
    </div>

    <?php if ($role === 'admin'): ?>
        <div class="form-container">
            <h3>Add New Hostel</h3>
            <form action="insert_hostel.php" method="post" enctype="multipart/form-data">
                <!-- Add Hostel Form Fields -->
                <div class="form-group">
                    <label for="hostelName">Hostel Name:</label>
                    <input type="text" id="hostelName" name="hostel_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="capacity">Capacity:</label>
                    <input type="number" id="capacity" name="capacity" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="status">Status:</label>
                    <select id="status" name="status" class="form-control" required>
                        <option value="1">Available</option>
                        <option value="0">Unavailable</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="4" required></textarea>
                </div>
                <br>
                <div class="form-group">
                    <label for="image">Image:</label>
                    <input type="file" id="image" name="image" class="form-control-file" accept="image/*" required>
                </div>
                <br>

                <button type="submit" class="btn btn-primary">Add Hostel</button>
            </form>
        </div>
    <?php endif; ?>
        <div class="property-list">
            <div class="property-list-title">List of Hostels</div>
            <div class="search-container">
                <input type="text" id="searchInput" onkeyup="searchHostel()" placeholder="Search for hostels..">
            </div>
            <table id="hostelTable" class="properties-table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Hostel Name</th>
                        <th>Capacity</th>
                        <th>Status</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php


if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $hostel_id = $row["Hostel_ID"];
        $hostel_name = $row["Name"];
        $capacity = $row["Capacity"];
        $status = $row["Status"] == 1 ? "Available" : "Unavailable";
        $image = base64_encode($row["image"]);
        $description = $row["description"];
        echo "<tr>";
        echo "<td><img src='data:image/jpeg;base64,$image' alt='Hostel Image' style='width:100px;height:auto;'/></td>";
        echo "<td>" . $hostel_name . "</td>";
        echo "<td>" . $capacity . "</td>";
        echo "<td>" . $status . "</td>";
        echo "<td>" . $description . "</td>";
        echo "<td>";
        echo "<button class='action-btn view-btn' onclick='viewHostel($hostel_id)'>View</button>";
        echo "<button class='action-btn edit-btn' onclick=\"editHostel('$hostel_id', '$hostel_name', '$capacity', '$status', '$image', '$description')\">Edit</button>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No hostels found</td></tr>";
}

$conn->close();
?> 
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Edit Hostel</h2>
            <form action="edit_hostel.php" method="post" enctype="multipart/form-data">
                <input type="hidden" id="editHostelId" name="hostel_id">
                <label for="editHostelName">Hostel Name:</label>
                <input type="text" id="editHostelName" name="hostel_name" required><br><br>
                <label for="editCapacity">Capacity:</label>
                <input type="number" id="editCapacity" name="capacity" required><br><br>
                <label for="editStatus">Status:</label>
                <select id="editStatus" name="status" required>
                    <option value="1">Available</option>
                    <option value="0">Unavailable</option>
                </select><br><br>
                <label for="editDescription">Description:</label>
                <textarea id="editDescription" name="description" required></textarea><br><br>
                <label for="editImage">Image:</label>
                <img id="editCurrentImage" src="" alt="Current Image" style="width:100px;height:auto;"><br><br>
                <input type="file" id="editImage" name="image" accept="image/*"><br><br>
                <button type="submit">Save Changes</button>
            </form>
        </div>
    </div>
</body>
</html>
