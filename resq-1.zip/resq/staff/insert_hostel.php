<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection settings
require '../mysqlconnection.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hostel_name = $conn->real_escape_string($_POST['hostel_name']);
    $capacity = intval($_POST['capacity']);
    $status = intval($_POST['status']);
    $description = $conn->real_escape_string($_POST['description']);

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = file_get_contents($_FILES['image']['tmp_name']);
    } else {
        $image = null;
    }

    // Begin transaction
    $conn->begin_transaction();

    try {
        // Insert hostel data
        $sql_insert_hostel = "INSERT INTO hostel (Name, Capacity, Status, image, description) VALUES ('$hostel_name', $capacity, $status, ?, '$description')";
        $stmt_insert_hostel = $conn->prepare($sql_insert_hostel);

        // Check if the statement was prepared successfully
        if ($stmt_insert_hostel === false) {
            throw new Exception("Error preparing statement: " . $conn->error);
        }

        $stmt_insert_hostel->send_long_data(0, $image); // Send image data as long data
        $stmt_insert_hostel->execute();

        if ($stmt_insert_hostel->affected_rows > 0) {
            $hostel_id = $stmt_insert_hostel->insert_id;

            // Get the highest Room_ID currently in the room table
            $sql_max_room_id = "SELECT MAX(Room_ID) AS max_room_id FROM room";
            $result_max_room_id = $conn->query($sql_max_room_id);
            $row_max_room_id = $result_max_room_id->fetch_assoc();
            $max_room_id = $row_max_room_id['max_room_id'];
            $next_room_id = $max_room_id + 1;

            // Insert rooms data
            $floors = 4; // Number of floors
            $houses_per_floor = 4; // Number of houses per floor
            $rooms_per_house = 2; // Number of rooms per house (A and B)

            // Prepare SQL statement for room insertion
            $sql_insert_room = "INSERT INTO room (Room_ID, Floor, House_No, Room_Name, Capacity, Status, Hostel_ID) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt_insert_room = $conn->prepare($sql_insert_room);

            // Check if the statement was prepared successfully
            if ($stmt_insert_room === false) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }

            // Loop through each floor and house to insert rooms
            for ($floor = 1; $floor <= $floors; $floor++) {
                for ($house_no = 1; $house_no <= $houses_per_floor; $house_no++) {
                    for ($room_number = 1; $room_number <= $rooms_per_house; $room_number++) {
                        $room_name = ($room_number == 1) ? 'A' : 'B';
                        $status = 1; // Assuming all rooms are initially available
                        $room_capacity = 2; // Assuming each room has a capacity of 2
                        $sql_insert_room = "INSERT INTO room (Room_ID, Floor, House_No, Room_Name, Capacity, Status, Hostel_ID) VALUES ($next_room_id, $floor, $house_no, '$room_name', $room_capacity, $status, $hostel_id)";
                        if (!$conn->query($sql_insert_room)) {
                            throw new Exception("Failed to insert room: Floor $floor, House $house_no, Room $room_name");
                        }

                        // Increment room ID for next room
                        $next_room_id++;
                    }
                }
            }

            // Commit transaction
            $conn->commit();

            echo "New hostel created successfully with rooms";
            header("Location: staffhostel.php");
            exit();
        } else {
            throw new Exception("Failed to insert hostel");
        }
    } catch (Exception $e) {
        // Rollback transaction in case of error
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }

    // Close statements
    $stmt_insert_hostel->close();
    $stmt_insert_room->close();
}

$conn->close();
?>
