<?php
require '../mysqlconnection.php';
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['staff_id'])) {
    echo json_encode(['message' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$oldPassword = $input['oldPassword'];
$newPassword = $input['newPassword'];

$staffId = $_SESSION['staff_id'];

$servername = "localhost"; // Change this to your database server
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "one_dormitory"; // Change this to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['message' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

// Fetch the hashed password
$sql = "SELECT Password FROM staff WHERE Staff_ID = $staffId";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    echo json_encode(['message' => 'Staff ID not found']);
    $conn->close();
    exit();
}

$row = $result->fetch_assoc();
$hashedPassword = $row['Password'];

if (!password_verify($oldPassword, $hashedPassword)) {
    echo json_encode(['message' => 'Incorrect old password']);
    $conn->close();
    exit();
}

// Hash the new password
$newHashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Update the password
$sql = "UPDATE staff SET Password = '$newHashedPassword' WHERE Staff_ID = $staffId";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['message' => 'Password changed successfully']);
} else {
    echo json_encode(['message' => 'Error updating password']);
}

$conn->close();
?>
