<?php
require '../mysqlconnection.php';

header('Content-Type: application/json');

if (isset($_GET['id'])) {
    $staff_id = intval($_GET['id']);

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        echo json_encode(["error" => "Connection failed: " . $conn->connect_error]);
        exit();
    }

    $sql = "SELECT * FROM staff WHERE Staff_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $staff = $result->fetch_assoc();
        
        // Convert image to base64
        if ($staff['Image']) {
            $staff['Image'] = 'data:image/jpeg;base64,' . base64_encode($staff['Image']);
        } else {
            $staff['Image'] = '';
        }
        
        echo json_encode($staff);
    } else {
        echo json_encode(["error" => "No staff found"]);
    }

    $conn->close();
} else {
    echo json_encode(["error" => "Invalid request"]);
}
