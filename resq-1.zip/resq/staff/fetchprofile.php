<?php
require '../mysqlconnection.php';

session_start();

if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/mainpage.html");
    exit();
}

$staffId = intval($_SESSION['staff_id']); // Sanitize the input

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Directly include the variable in the SQL query
$sql = "SELECT Name, Phone, Age, Email, Image FROM staff WHERE Staff_ID = $staffId";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $profile = $result->fetch_assoc();

    if ($profile['Image']) {
        $profile['Image'] = base64_encode($profile['Image']);
    }

    echo json_encode($profile);
} else {
    echo json_encode(['error' => 'No profile found']);
}

$conn->close();
?>
