<?php
session_start();
    if (!isset($_SESSION['staff_id'])) {
        header("Location: /fyp/login.html");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ced3c4;
            color: #fff;
            padding-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar a {
            display: block;
            color: #0c0c0c;
            padding: 10px;
            text-decoration: none;
            text-align: center;
            font-size: 17px;
        }

        .sidebar a:hover {
            background-color: #8f9779;
        }



        .table-container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            width: 100%;
        }
        
        .table {
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 100%;
            max-width: 800px;
            margin-top: 50px;
        }

        .table-border {
            padding: 16px;
        }

        .table-header {
            margin-bottom: 16px;
            text-align: center;
        }

        .table-header-title {
            font-size: 1.8em;
            font-weight: bold;
            text-align: center;
        }

        .content-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }

        .content-table th,
        .content-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .content-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .action-btn {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 2px 1px;
            cursor: pointer;
            border-radius: 5px;
        }

        .action-btn.view {
            background-color: #2196F3;
        }

        .action-btn.edit {
            background-color: #FFC107;
        }

        .action-btn.terminate {
            background-color: #f44336;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .student-details {
            text-align: center;
        }

        .student-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .title {
            text-align: center;
            margin-bottom: 20px;
            width: 100%;
        }
        .dashboard-box {
            width: 200px;
            height: 150px;
            background-color: #ced3c4;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
        .dashboard-box:hover {
            background-color: #8f9779;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            margin-top: 0px;
        }

        .logo img {
            width: 45px;
            margin-right: 10px;
        }

        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 10px;
            text-align: center;
            width: 30%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }



        .header-logo img {
            width: 100px;
        }

        footer {
            background-color: #f0f0f0;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            margin-left: 250px;
        }

        .search-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-input {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 200px;
            margin-right: 10px;
        }

        .search-btn {
            padding: 8px 16px;
            border-radius: 5px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        .search-btn:hover {
            background-color: #45a049;
        }
    </style>

    <script>
        function viewStudent(id) {
            var modal = document.getElementById("myModal");
            modal.style.display = "block";

            var xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_student.php?id=" + id, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    var student = JSON.parse(xhr.responseText);
                    if (student.error) {
                        alert(student.error);
                    } else {
                        document.getElementById("studentName").innerHTML = student.Name;
                        document.getElementById("studentMatricNo").innerHTML = student.Matric_No;
                        document.getElementById("studentFaculty").innerHTML = student.Faculty;
                        document.getElementById("studentProgram").innerHTML = student.Program;
                        document.getElementById("studentPhoneNo").innerHTML = student.Phone_No;
                        document.getElementById("studentAge").innerHTML = student.Age;
                        document.getElementById("studentEmail").innerHTML = student.Email;
                        document.getElementById("studentGender").innerHTML = student.Gender;
                        document.getElementById("studentImage").src = student.Avatar;
                    }
                } else {
                    alert("Error fetching student details.");
                }
            };
            xhr.send();
        }

        function closeModal() {
            var modal = document.getElementById("myModal");
            modal.style.display = "none";
        }

        function searchStudent() {
            var input = document.getElementById("searchInput").value.toUpperCase();
            var rows = document.getElementsByTagName("tr");

            for (var i = 0; i < rows.length; i++) {
                var nameColumn = rows[i].getElementsByTagName("td")[1];

                if (nameColumn) {
                    var name = nameColumn.textContent || nameColumn.innerText;
                    if (name.toUpperCase().indexOf(input) > -1) {
                        rows[i].style.display = "";
                    } else {
                        rows[i].style.display = "none";
                    }
                }
            }
        }

        function editStudent(id) {
            var modal = document.getElementById("editModal");
            modal.style.display = "block";

            var xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_student.php?id=" + id, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    var student = JSON.parse(xhr.responseText);
                    if (student.error) {
                        alert(student.error);
                    } else {
                        document.getElementById("editStudentId").value = student.Student_ID;
                        document.getElementById("editName").value = student.Name;
                        document.getElementById("editAge").value = student.Age;
                    }
                } else {
                    alert("Error fetching student details.");
                }
            };
            xhr.send();
        }

        function closeEditModal() {
            var modal = document.getElementById("editModal");
            modal.style.display = "none";
        }

        function saveStudent() {
            var form = document.getElementById("editForm");
            var formData = new FormData(form);
            
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "savestudent.php", true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    alert(xhr.responseText);
                    location.reload();
                } else {
                    alert("Error updating student details.");
                }
            };
            xhr.send(formData);
        }
    </script>

</head>
<body>

    <?php 
include 'layout/header.php'; 
?>


<div class="content">
    <div class="table-container">
        <div class="table">
            <div class="table-border">
                <div class="table-header">
                    <div class="table-header-title">Students</div>
                </div>
                <div class="search-container">
                    <input type="text" id="searchInput" class="search-input" placeholder="Search student by name">
                    <button class="search-btn" onclick="searchStudent()">Search</button>
                </div>
                <table class="content-table">
                    <thead>
                        <tr>
                            <th>Count</th>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    
                    // Retrieve role from session
                    $role = $_SESSION['role'];

                    // Connect to the database
                    require '../mysqlconnection.php';
                    $conn = new mysqli($servername, $username, $password, $database);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Define the SQL query based on the role
                    if ($role === 'admin') {
                        // Admins can see all students
                        $sql = "SELECT * FROM student";
                    } else {
                        // Staff can only see students in their associated hostel
                        $staff_id = $_SESSION['staff_id'];
                        $sql = "SELECT student.* 
                                FROM student
                                INNER JOIN placement ON student.Student_ID = placement.Student_ID
                                INNER JOIN room ON placement.Room_ID = room.Room_ID
                                INNER JOIN hostel ON room.Hostel_ID = hostel.Hostel_ID
                                JOIN staff ON staff.hostel_id=hostel.Hostel_ID
                                WHERE staff.Staff_ID = ?
                                AND placement.status=1";
                    }

                    if ($role === 'admin') {
                        $result = $conn->query($sql);
                    } else {
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $staff_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                    }

                    if ($result->num_rows > 0) {
                        $count = 1;
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $count++ . "</td>";
                            echo "<td>" . htmlspecialchars($row["Name"]) . "</td>";
                            echo "<td>
                                    <button class='action-btn view' onclick='viewStudent(" . $row["Student_ID"] . ")'>View</button>
                                  </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No students found</td></tr>";
                    }

                    // Close the database connection
                    $conn->close();
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

    <!-- View Modal -->
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <div class="student-details">
                <img id="studentImage" class="student-image" src="" alt="Student Image">
                <h3 id="studentName"></h3>
                <p><strong>Matric No:</strong> <span id="studentMatricNo"></span></p>
                <p><strong>Faculty:</strong> <span id="studentFaculty"></span></p>
                <p><strong>Program:</strong> <span id="studentProgram"></span></p>
                <p><strong>Phone No:</strong> <span id="studentPhoneNo"></span></p>
                <p><strong>Age:</strong> <span id="studentAge"></span></p>
                <p><strong>Email:</strong> <span id="studentEmail"></span></p>
                <p><strong>Gender:</strong> <span id="studentGender"></span></p>
            </div>
        </div>
    </div>

</body>
</html>