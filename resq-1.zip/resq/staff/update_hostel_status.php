<?php
// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $staff_id = intval($_POST['placement_id']);
    $status = $_POST['status'];

    // Reset hostel ID if status is empty
    if ($status === '') {
        $updateHostelSql = "UPDATE staff SET hostel_id = '0' WHERE Staff_ID = ?";
        $stmt = $conn->prepare($updateHostelSql);
        $stmt->bind_param("i", $staff_id);
        if ($stmt->execute() === false) {
            echo json_encode(['success' => false, 'message' => "Error updating hostel_id: " . $stmt->error]);
            exit;
        }
        $stmt->close();
    }

    // Update status
    $updateStatusSql = "UPDATE staff SET status = ? WHERE Staff_ID = ?";
    $stmt = $conn->prepare($updateStatusSql);
    $stmt->bind_param("si", $status, $staff_id);
    if ($stmt->execute() === true) {
        echo json_encode(['success' => true, 'message' => "Status updated successfully"]);
    } else {
        echo json_encode(['success' => false, 'message' => "Error updating status: " . $stmt->error]);
    }
    $stmt->close();
}

$conn->close();
?>
