<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ced3c4;
            color: #fff;
            padding-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar a {
            display: block;
            color: #0c0c0c;
            padding: 10px;
            text-decoration: none;
            text-align: center;
            font-size: 17px;
        }

        .sidebar a:hover {
            background-color: #8f9779;
        }


        .title {
            text-align: center;
            margin-bottom: 20px;
            width: 100%;
        }
        .requests-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .requests-table th, .requests-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .requests-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .action-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            color: #fff;
            font-size: 12px;
        }
        .approve-btn {
            background-color: #4CAF50;
        }
        .approve-btn:hover {
            background-color: #45a049;
        }
        .reject-btn {
            background-color: #f44336;
        }
        .reject-btn:hover {
            background-color: #d32f2f;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            margin-top: 0px;
        }

        .logo img {
            width: 45px;
            margin-right: 10px;
        }

        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 10px;
            text-align: center;
            width: 30%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }
    </style>
    <script>
        function updateStatus(placementId, status, roomid) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "update_placement_status.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    location.reload();
                }
            };
            xhr.send("placement_id=" + placementId + "&status=" + status + "&Room_id=" + roomid);
        }
    </script>
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['staff_id'])) {
        header("Location: /fyp/mainpage.html");
        exit();
    }
    ?>
    <?php 
include 'layout/header.php'; 
?>

    <div class="content">
        <div class="title">
            <h2>Student Placement Requests</h2>
        </div>
        <table class="requests-table">
            <thead>
                <tr>
                    <th>Request Date</th>
                    <th>Start Date</th>
                    <th>Duration</th>
                  
                    <th>Total</th>
                    <th>Student Name</th>
                    <th>Hostel Name</th>
                    <th>Room Details</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection settings
                require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user role from session
$role = $_SESSION['role'];
$staff_id = $_SESSION['staff_id']; // For staff-specific filtering

if ($role === 'admin') {
    // Admin can view all placement requests
    $sql = "
        SELECT p.Placement_ID, p.Date, p.StartDate, p.Duration, p.Total, p.Balance, s.Name as Student_Name, r.Floor, r.House_No, r.Room_Name, h.Name, r.Room_ID
        FROM placement p
        JOIN student s ON p.Student_ID = s.Student_ID
        JOIN room r ON p.Room_ID = r.Room_ID
        JOIN hostel h ON h.Hostel_ID = r.Hostel_ID
        WHERE p.Status = 2
    ";
} else {
    // Staff can only view placement requests from their hostel
    $sql = "
        SELECT p.Placement_ID, p.Date, p.StartDate, p.Duration, p.Total, p.Balance, s.Name as Student_Name, r.Floor, r.House_No, r.Room_Name, h.Name, r.Room_ID
        FROM placement p
        JOIN student s ON p.Student_ID = s.Student_ID
        JOIN room r ON p.Room_ID = r.Room_ID
        JOIN hostel h ON h.Hostel_ID = r.Hostel_ID
        JOIN staff st ON st.hostel_id = h.Hostel_ID
        WHERE p.Status = 2 AND st.Staff_ID = $staff_id AND st.status='DONE'
    ";
}

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["Date"] . "</td>";
        echo "<td>" . $row["StartDate"] . "</td>";
        echo "<td>" . $row["Duration"] . "</td>";
        echo "<td>" . $row["Balance"] . "</td>";
        echo "<td>" . $row["Student_Name"] . "</td>";
        echo "<td>" . $row["Name"] . "</td>";
        echo "<td>Floor: " . $row["Floor"] . ", House: " . $row["House_No"] . ", Room: " . $row["Room_Name"] . "</td>";
        echo "<td>";
        echo "<button class='action-btn approve-btn' onclick='updateStatus(" . $row["Placement_ID"] . ", 1, " . $row["Room_ID"] . ")'>Approve</button> ";
        echo "<button class='action-btn reject-btn' onclick='updateStatus(" . $row["Placement_ID"] . ", 3, " . $row["Room_ID"] . ")'>Reject</button>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='8'>No placement requests found</td></tr>";
}

$conn->close();
?>
            </tbody>
        </table>
    </div>
</body>
</html>
