<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Rooms</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .content {
            margin: 20px;
        }
        .title {
            text-align: center;
            margin-bottom: 20px;
        }
        .filter-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .filter-container select {
            padding: 10px;
            margin: 5px;
            font-size: 16px;
        }
        .rooms-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .rooms-table th, .rooms-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .rooms-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .back-btn, .add-room-btn {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-btn:hover, .add-room-btn:hover {
            background-color: #0056b3;
        }
        .form-container {
            margin-top: 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container h3 {
            margin-top: 0;
        }
        .form-container form {
            display: flex;
            flex-wrap: wrap;
        }
        .form-container form div {
            margin-right: 10px;
            margin-bottom: 10px;
            flex: 1 1 200px;
        }
        .form-container form div label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container form div input, .form-container form div select {
            width: 100%;
            padding: 8px;
            font-size: 16px;
        }
    </style>
    <script>
        function filterRooms() {
            let houseNameFilter = document.getElementById('filterHouseName').value.toUpperCase();
            let floorFilter = document.getElementById('filterFloor').value.toUpperCase();
            let houseNoFilter = document.getElementById('filterHouseNo').value.toUpperCase();
            let statusFilter = document.getElementById('filterStatus').value.toUpperCase();
            let table = document.getElementById('roomTable');
            let tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                let tdHouseName = tr[i].getElementsByTagName('td')[2];
                let tdFloor = tr[i].getElementsByTagName('td')[0];
                let tdHouseNo = tr[i].getElementsByTagName('td')[1];
                let tdStatus = tr[i].getElementsByTagName('td')[4];

                if (tdHouseName && tdFloor && tdHouseNo && tdStatus) {
                    let houseNameValue = tdHouseName.textContent || tdHouseName.innerText;
                    let floorValue = tdFloor.textContent || tdFloor.innerText;
                    let houseNoValue = tdHouseNo.textContent || tdHouseNo.innerText;
                    let statusValue = tdStatus.textContent || tdStatus.innerText;

                    if ((houseNameFilter === "" || houseNameValue.toUpperCase().indexOf(houseNameFilter) > -1) &&
                        (floorFilter === "" || floorValue.toUpperCase().indexOf(floorFilter) > -1) &&
                        (houseNoFilter === "" || houseNoValue.toUpperCase().indexOf(houseNoFilter) > -1) &&
                        (statusFilter === "" || statusValue.toUpperCase().indexOf(statusFilter) > -1)) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</head>
<body>
    <div class="content">
        <div class="title">
            <h2>Rooms in Hostel</h2>
        </div>
        <div class="filter-container">
            <select id="filterHouseName" onchange="filterRooms()">
                <option value="">All House Names</option>
                <?php
                // Populate house names from database
                $conn = new mysqli("localhost", "root", "", "one_dormitory");
                $houseNames = $conn->query("SELECT DISTINCT Room_Name FROM room");
                while ($row = $houseNames->fetch_assoc()) {
                    echo "<option value='{$row['Room_Name']}'>{$row['Room_Name']}</option>";
                }
                ?>
            </select>
            <select id="filterFloor" onchange="filterRooms()">
                <option value="">All Floors</option>
                <?php
                // Populate floors from database
                $floors = $conn->query("SELECT DISTINCT Floor FROM room");
                while ($row = $floors->fetch_assoc()) {
                    echo "<option value='{$row['Floor']}'>{$row['Floor']}</option>";
                }
                ?>
            </select>
            <select id="filterHouseNo" onchange="filterRooms()">
                <option value="">All House Numbers</option>
                <?php
                // Populate house numbers from database
                $houseNos = $conn->query("SELECT DISTINCT House_No FROM room");
                while ($row = $houseNos->fetch_assoc()) {
                    echo "<option value='{$row['House_No']}'>{$row['House_No']}</option>";
                }
                ?>
            </select>
            <select id="filterStatus" onchange="filterRooms()">
                <option value="">All Status</option>
                <option value="Available">Available</option>
                <option value="Occupied">Occupied</option>
            </select>
        </div>
        <table id="roomTable" class="rooms-table">
            <thead>
                <tr>
                    <th>Floor</th>
                    <th>House No</th>
                    <th>Room Name</th>
                    <th>Capacity</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Get Hostel_ID from URL
                $hostel_id = isset($_GET['hostel_id']) ? intval($_GET['hostel_id']) : 0;

                // Fetch room data based on Hostel_ID and sort by Floor, House No, and Room Name
                $sql = "SELECT room.*, hostel.Name AS Hostel_Name FROM room JOIN hostel ON room.Hostel_ID = hostel.Hostel_ID WHERE room.Hostel_ID = $hostel_id ORDER BY Floor, House_No, Room_Name";
                $result = $conn->query($sql);


                if ($result && $result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["Floor"] . "</td>";
                        echo "<td>" . $row["House_No"] . "</td>";
                        echo "<td>" . $row["Room_Name"] . "</td>";
                        echo "<td>" . $row["Capacity"] . "</td>";
                        echo "<td>" . ($row["Status"] == 1 ? "Available" : "Occupied") . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No rooms found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="staffhostel.php" class="back-btn">Back to Hostels</a>
       
    </div>
    <?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hostel_id = intval($_POST['hostel_id']);
    $floor = intval($_POST['floor']);
    $house_no = intval($_POST['house_no']);
    $room_name = $_POST['room_name'];
    $capacity = intval($_POST['capacity']);
    $status = intval($_POST['status']);

    // Retrieve the largest existing Room_ID and increment it by 1
    $result = $conn->query("SELECT MAX(Room_ID) AS max_id FROM room");
    $row = $result->fetch_assoc();
    $new_room_id = $row['max_id'] + 1;

    // Check if the room already exists
    $check_sql = "SELECT * FROM room WHERE Hostel_ID = $hostel_id AND Floor = $floor AND House_No = $house_no AND Room_Name = '$room_name' AND Status = 1";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo "<p>Room with the same floor, house number, and name already exists and is available.</p>";
    } else {
        $insert_sql = "INSERT INTO room (Room_ID, Floor, House_No, Room_Name, Capacity, Status, Hostel_ID) VALUES ($new_room_id, $floor, $house_no, '$room_name', $capacity, $status, $hostel_id)";
        if ($conn->query($insert_sql) === TRUE) {
            echo "<p>Room added successfully!</p>";
        } else {
            echo "<p>Error: " . $conn->error . "</p>";
        }
    }

    $conn->close();
}
?>

</body>
</html>
