<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/login.html");
    exit();
}

// Database connection settings
require '../mysqlconnection.php';
include 'layout/header.php';

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user role and staff ID from session
$staff_id = $_SESSION['staff_id'];

// Check if staff already has a hostel assigned
$sql = "SELECT hostel_id FROM staff WHERE staff_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$stmt->bind_result($assigned_hostel_id);
$stmt->fetch();
$stmt->close();

if ($assigned_hostel_id) {
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
        Swal.fire({
            icon: 'info',
            title: 'Hostel Already Assigned or Requested',
            text: 'Wait for Admin to accept your request.',
            confirmButtonText: 'OK',
            allowOutsideClick: false,
            allowEscapeKey: false,
        }).then((result) => {
            window.location.href = 'staffhomepage.php';
        });
    </script>";
    exit();
}

// Fetch available hostels
$sql = "SELECT Hostel_ID, Name, Capacity, Status, image, description FROM hostel WHERE Status = 1";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Hostel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 50px auto;
        }
        .title {
            text-align: center;
            margin-bottom: 20px;
        }
        .hostel-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .hostel-box {
            width: 300px;
            border: 1px solid #ddd;
            border-radius: 10px;
            margin: 10px;
            padding: 20px;
            background-color: #fff;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .hostel-box img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .hostel-name {
            font-size: 20px;
            font-weight: bold;
            margin-top: 10px;
        }
        .hostel-capacity {
            margin: 10px 0;
        }
        .assign-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
        }
        .assign-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title">
            <h2>Select a Hostel to Assign</h2>
        </div>
        <div class="hostel-list">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="hostel-box">
                        <img src="data:image/jpeg;base64,<?= base64_encode($row['image']); ?>" alt="Hostel Image">
                        <div class="hostel-name"><?= htmlspecialchars($row['Name']); ?></div>
                        <div class="hostel-capacity">Capacity: <?= htmlspecialchars($row['Capacity']); ?></div>
                        <div class="hostel-description"><?= htmlspecialchars($row['description']); ?></div>
                        <button class="assign-btn" onclick="assignHostel(<?= $row['Hostel_ID']; ?>)">Assign</button>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No available hostels to assign.</p>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function assignHostel(hostel_id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You want to assign this hostel?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, assign it!',
                cancelButtonText: 'No, cancel!',
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redirect to the backend script to assign the hostel
                    window.location.href = 'assign_hostel.php?hostel_id=' + hostel_id;
                }
            });
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
