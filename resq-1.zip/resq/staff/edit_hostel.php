<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection settings
require '../mysqlconnection.php';


// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $hostel_id = $_POST["hostel_id"];
    $hostel_name = $_POST["hostel_name"];
    $capacity = $_POST["capacity"];
    $status = $_POST["status"];
    $description = $_POST["description"];
    
    if (!empty($_FILES["image"]["tmp_name"])) {
        $image = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
        $sql = "UPDATE hostel SET Name='$hostel_name', Capacity='$capacity', Status='$status', image='$image', decsription='$description' WHERE Hostel_ID='$hostel_id'";
    } else {
        $sql = "UPDATE hostel SET Name='$hostel_name', Capacity='$capacity', Status='$status', description='$description' WHERE Hostel_ID='$hostel_id'";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Hostel updated successfully";
        header("Location: staffhostel.php"); // Redirect back to staffhostel.php after update
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
