<?php
require '../mysqlconnection.php';

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['placement_id'])) {
    // Sanitize the input to prevent SQL injection
    $placementId = intval($_GET['placement_id']); // Cast to integer for security

    // Directly include the variable in the SQL query
    $sql = "SELECT * FROM placement WHERE Placement_ID = $placementId";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<p>Placement ID: " . htmlspecialchars($row['Placement_ID']) . "</p>";
            echo "<p>Date: " . htmlspecialchars($row['Date']) . "</p>";
            echo "<p>Start Date: " . htmlspecialchars($row['StartDate']) . "</p>";
            echo "<p>Duration: " . htmlspecialchars($row['Duration']) . "</p>";
            echo "<p>Total: " . htmlspecialchars($row['Total']) . "</p>";
            echo "<p>Balance: " . htmlspecialchars($row['Balance']) . "</p>";
            echo "<p>Status: " . htmlspecialchars($row['Status']) . "</p>";
            echo "<p>Student ID: " . htmlspecialchars($row['Student_ID']) . "</p>";
            echo "<p>Room ID: " . htmlspecialchars($row['Room_ID']) . "</p>";
        }
    } else {
        echo "<p>No details found for this placement ID.</p>";
    }
} else {
    echo "<p>Invalid placement ID.</p>";
}

$conn->close();
?>
