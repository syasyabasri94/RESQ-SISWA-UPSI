<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/mainpage.html");
    exit();
}

require '../mysqlconnection.php';
// Establishing connection to database
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default values and input handling
$hostel_id = isset($_GET['hostel_id']) ? intval($_GET['hostel_id']) : 0;
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';

// Prepare base SQL query
$sql = "SELECT student.Student_ID, student.Name, room.Floor, room.House_No, room.Room_Name, placement.StartDate, placement.Status, placement.Placement_ID
        FROM placement
        INNER JOIN student ON placement.Student_ID = student.Student_ID
        INNER JOIN room ON placement.Room_ID = room.Room_ID
        INNER JOIN (
            SELECT Student_ID, MAX(Placement_ID) AS LatestPlacementID
            FROM placement 
            GROUP BY Student_ID
        ) AS LatestPlacement ON placement.Student_ID = LatestPlacement.Student_ID AND placement.Placement_ID = LatestPlacement.LatestPlacementID
        WHERE room.Hostel_ID = $hostel_id";

// Add status filter if provided
if (!empty($statusFilter)) {
    if ($statusFilter == 'Active') {
        $sql .= " AND placement.Status != 3"; // Active status
    } elseif ($statusFilter == 'Inactive') {
        $sql .= " AND placement.Status = 3"; // Inactive or Rejected status
    }
}

$sql .= " ORDER BY placement.Placement_ID ASC";

// Fetch students from database
$result = $conn->query($sql);

$students = [];
while ($row = $result->fetch_assoc()) {
    $status = $row['Status'] == 3 ? 'Inactive' : 'Active';

    $students[] = [
        'student_id' => $row['Student_ID'],
        'name' => $row['Name'],
        'floor' => $row['Floor'],
        'house_no' => $row['House_No'],
        'room_name' => $row['Room_Name'],
        'status' => $status
    ];
}

$conn->close();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Students</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            background-color: #ced3c4;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .student-info {
            display: flex;
            flex-direction: column;
        }
        .room-info {
            display: flex;
            flex-direction: column;
        }
        .action-btn {
            background-color: #f44336;
            border: none;
            color: white;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 2px 1px;
            cursor: pointer;
            border-radius: 5px;
        }
        .action-btn[disabled] {
            background-color: #ccc;
            cursor: not-allowed;
        }
        ul {
            list-style-type: none; /* Remove bullet points */
            padding: 0; /* Remove padding */
        }
        .student-row {
            display: flex;
            align-items: center; /* Center items vertically */
            justify-content: space-between; /* Space out items evenly */
            padding: 10px;
            border-bottom: 1px solid #ccc; /* Optional: Add a border for separation */
        }
        .student-info, .room-info, .action-button {
            flex: 1; /* Make each div take up equal space */
        }
        .student-info {
            flex: 2; /* Make student-info take up more space */
        }
        .room-info {
            display: flex;
            flex-direction: column;
        }
        .action-button {
            text-align: right; /* Align the button to the right */
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#status').change(function() {
                var status = $(this).val();
                var hostel_id = <?php echo $hostel_id; ?>;
                
                // Redirect to the same page with status filter
                window.location.href = '/fyp/staff/hostel_students.php?status=' + status + '&hostel_id=' + hostel_id;
            });
        });
        
        function terminateStudent(studentId) {
            if (confirm("Are you sure you want to terminate this student?")) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "terminate_student.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onload = function() {
                    if (xhr.status === 200) {
                        alert(xhr.responseText);
                        location.reload();
                    } else {
                        alert("Error terminating student.");
                    }
                };
                xhr.send("student_id=" + studentId);
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Students in Hostel</h2>

        <!-- Status Filter Form -->
        <form method="GET" action="">
            <label for="status">Filter by Status:</label>
            <select name="status" id="status">
                <option value="">All</option>
                <option value="Active" <?php echo ($statusFilter == 'Active') ? 'selected' : ''; ?>>Active</option>
                <option value="Inactive" <?php echo ($statusFilter == 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
            </select>
            <input type="hidden" name="hostel_id" value="<?php echo $hostel_id; ?>">
        </form>

        <!-- Student List -->
        <?php if (empty($students)): ?>
            <p>No students found.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($students as $student): ?>
                    <li class="student-row">
                        <div class="student-info">
                            <strong><?php echo htmlspecialchars($student['name']); ?></strong>
                        </div>
                        <div class="room-info">
                            <span>Floor: <?php echo htmlspecialchars($student['floor']); ?></span>
                            <span>House No: <?php echo htmlspecialchars($student['house_no']); ?></span>
                            <span>Room: <?php echo htmlspecialchars($student['room_name']); ?></span>
                        </div>
                        <div class="room-info">
                            <span>Status :<?php echo htmlspecialchars($student['status']); ?></span>
                        </div>
                        <div class="action-button">
                            <?php if ($student['status'] == 'Active'): ?>
                                <button class="action-btn" onclick="terminateStudent(<?php echo htmlspecialchars($student['student_id']); ?>)">Terminate</button>
                            <?php else: ?>
                                <button class="action-btn" disabled>Terminate</button>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</body>
</html>
