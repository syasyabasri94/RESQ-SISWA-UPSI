<?php
session_start();
require("config.php");
require("function.php");
myconnectionDB();

// Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    echo json_encode(["error" => "You are not logged in."]);
    exit();
}

// Get student ID from session
$student_id = $_SESSION['student_id'];

// Fetch student profile data from the database
$sql = "SELECT Name, Matric_No, Age, Faculty, Program, Gender, Phone_No, Email FROM student WHERE StudentID = $student_id";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    echo json_encode([
        "name" => $row['Name'],
        "matric_no" => $row['Matric_No'],
        "age" => $row['Age'],
        "faculty" => $row['Faculty'],
        "program" => $row['Program'],
        "gender" => $row['Gender'],
        "phone_no" => $row['Phone_No'],
        "email" => $row['Email']
    ]);
} else {
    echo json_encode(["error" => "Failed to execute SQL statement: " . $conn->error]);
    exit();
}


// Close the database connection
$conn->close();
?>
