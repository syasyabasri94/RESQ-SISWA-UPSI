<?php
require '../mysqlconnection.php';

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = intval($_POST['Student_ID']);
    $name = $conn->real_escape_string($_POST['Name']);
    $age = intval($_POST['Age']);

    $sql = "UPDATE student SET Name='$name', Age=$age WHERE Student_ID=$studentId";

    if ($conn->query($sql) === TRUE) {
        echo "Student details updated successfully!";
    } else {
        echo "Error updating student details: " . $conn->error;
    }
}

$conn->close();
?>
