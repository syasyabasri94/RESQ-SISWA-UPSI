<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Homepage</title>
    <style>
        /* Existing styles... */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ced3c4;
            color: #fff;
            padding-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar a {
            display: block;
            color: #0c0c0c;
            padding: 10px;
            text-decoration: none;
            text-align: center;
            font-size: 17px;
        }

        .sidebar a:hover {
            background-color: #8f9779;
        }

        .content {
            margin-left: 300px;
            padding: 30px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .title {
            text-align: center;
            margin-bottom: 20px;
            width: 100%;
        }
        .dashboard-box {
            width: 200px;
            height: 150px;
            background-color: #ced3c4;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
        .dashboard-box:hover {
            background-color: #8f9779;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            margin-top: 0px;
        }

        .logo img {
            width: 45px;
            margin-right: 10px;
        }

        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 10px;
            text-align: center;
            width: 30%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }

        section {
            margin-bottom: 20px;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse; /* Collapses borders into a single border */
        }

        table th, table td {
            padding: 8px;
            border: 2px solid #ccc; /* 1px solid border around each cell */
            font-weight: bold; /* Makes text inside cells bold */

        }

        table th {
            background-color: #f0f0f0; /* Optional: Background color for header cells */
            font-weight: bold; /* Optional: Makes header cells bold */
        }


        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .fees-data, .fees-status, .complaints-data {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .complaints-data p {
            font-weight: bold;
        }

        footer {
            background-color: #f0f0f0;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            margin-left: 250px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/login.html");
    exit();
}

require '../mysqlconnection.php';

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve role from session
$role = $_SESSION['role'];

// SQL for fetching hostels based on role
if ($role === 'admin') {
    // Admins can see all hostels
    $sql = "SELECT hostel.Hostel_ID, hostel.Name, 
                   (COUNT(placement.Placement_ID) / hostel.Capacity) * 100 AS OccupancyPercentage
            FROM hostel
            LEFT JOIN room ON hostel.Hostel_ID = room.Hostel_ID
            LEFT JOIN placement ON room.Room_ID = placement.Room_ID AND placement.Status = 1
            GROUP BY hostel.Hostel_ID";
            
            $result = $conn->query($sql);

} else {
    // Staff can only see their associated hostels
    $staff_id = $_SESSION['staff_id'];
    $sql = "SELECT hostel.Hostel_ID, hostel.Name, 
                   (COUNT(placement.Placement_ID) / hostel.Capacity) * 100 AS OccupancyPercentage
            FROM hostel
            LEFT JOIN room ON hostel.Hostel_ID = room.Hostel_ID
            LEFT JOIN placement ON room.Room_ID = placement.Room_ID AND placement.Status = 1
            JOIN staff ON staff.hostel_id=hostel.Hostel_ID
            WHERE staff.Staff_ID = ? AND staff.status='DONE'
            GROUP BY hostel.Hostel_ID";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $staff_id);
            $stmt->execute();
            $result = $stmt->get_result();

}

    

$hostelData = [];
while ($row = $result->fetch_assoc()) {
    $hostelData[] = [
        'id' => $row['Hostel_ID'],
        'name' => $row['Name'],
        'occupancy' => number_format($row['OccupancyPercentage'], 2)
    ];
}

// Fetch complaint data
if ($role === 'admin') {
    // Admin: Fetch all complaints
    $total_sql = "SELECT COUNT(*) as total FROM complaint";
    $resolved_sql = "SELECT COUNT(*) as resolved FROM complaint WHERE Remark = 'resolved'";
    $open_sql = "SELECT COUNT(*) as open FROM complaint WHERE Remark = 'open'";
} else {
    // Staff: Fetch complaints related to the staff's assigned hostel
    $total_sql = "SELECT COUNT(*) as total 
                  FROM complaint
                  JOIN placement ON placement.student_id=complaint.student_id
                  JOIN room ON room.Room_ID = placement.Room_ID
                  JOIN hostel ON hostel.Hostel_ID= room.Hostel_ID
                  WHERE hostel.Hostel_ID = (SELECT hostel_id FROM staff WHERE staff_id = $staff_id AND status='DONE')";
    
    $resolved_sql = "SELECT COUNT(*) as resolved 
                     FROM complaint 
                     JOIN placement ON placement.student_id=complaint.student_id
                    JOIN room ON room.Room_ID = placement.Room_ID
                    JOIN hostel ON hostel.Hostel_ID= room.Hostel_ID 
                     WHERE Remark = 'resolved' 
                     AND hostel.Hostel_ID = (SELECT hostel_id FROM staff WHERE staff_id = $staff_id AND status='DONE')";
    
    $open_sql = "SELECT COUNT(*) as open 
                 FROM complaint 
                 JOIN placement ON placement.student_id=complaint.student_id
                    JOIN room ON room.Room_ID = placement.Room_ID
                    JOIN hostel ON hostel.Hostel_ID= room.Hostel_ID 
                 WHERE Remark = 'open' 
                 AND hostel.Hostel_ID = (SELECT hostel_id FROM staff WHERE staff_id = $staff_id AND status='DONE')";
}

$total_result = $conn->query($total_sql);
$resolved_result = $conn->query($resolved_sql);
$open_result = $conn->query($open_sql);

$total = $total_result->fetch_assoc()['total'];
$resolved = $resolved_result->fetch_assoc()['resolved'];
$open = $open_result->fetch_assoc()['open'];

include 'layout/header.php';
?>
    <main>
        <section class="occupancy">
            <h2>Occupancy</h2>
            <table>
                <thead>
                    <tr>
                        <th>Hostel</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($hostelData) > 0) {
                        foreach ($hostelData as $hostel) {
                            echo "<tr>
                                    <td><a href='hostel_students.php?hostel_id=" . $hostel['id'] . "'>" . htmlspecialchars($hostel['name']) . "</a></td>
                                    <td>" . $hostel['occupancy'] . "%</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2'>No data available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>

        <section class="complaints">
            <h2>Complaints</h2>
            <div class="complaints-data">
                <p><a href="complaints.php?type=total">Total: <?php echo $total; ?></a></p>
                <p><a href="complaints.php?type=resolved">Resolved: <?php echo $resolved; ?></a></p>
                <p><a href="complaints.php?type=open"></a></p>
            </div>
        </section>

        <section class="charts">
            <h2>Occupancy Charts</h2>
            <div id="chart-container">
                <?php foreach ($hostelData as $hostel): ?>
                    <div class="chart" style="width: 300px; height: 300px; display: inline-block;">
                        <canvas id="chart-<?php echo $hostel['id']; ?>"></canvas>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
    <?php $conn->close(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var hostels = <?php echo json_encode($hostelData); ?>;

            hostels.forEach(function (hostel) {
                var ctx = document.getElementById('chart-' + hostel.id).getContext('2d');
                new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: ['Occupied', 'Vacant'],
                        datasets: [{
                            data: [hostel.occupancy, 100 - hostel.occupancy],
                            backgroundColor: ['#8f9779', '#ced3c4'],
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top',
                            },
                            title: {
                                display: true,
                                text: hostel.name
                            }
                        }
                    },
                });
            });
        });
    </script>
</body>
</html>
