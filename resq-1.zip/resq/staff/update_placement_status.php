<?php
// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $placement_id = intval($_POST['placement_id']);
    $status = intval($_POST['status']);
    $roomid=intval($_POST['Room_id']);
    if ($status == '3') {
        $updateSql = "UPDATE room SET Capacity = Capacity + 1 WHERE Room_ID = $roomid";
        if ($conn->query($updateSql) === FALSE) {
            echo json_encode(['success' => false, 'message' => "Error updating room capacity: " . $conn->error]);
            exit;
        }
    }

    // Update placement status
    // Update placement status
$sql = "UPDATE placement SET Status = $status WHERE Placement_ID = $placement_id";
if ($conn->query($sql) === TRUE) {
    echo "Status updated successfully";
} else {
    echo "Error updating status: " . $conn->error;
}

    $stmt->close();
}

$conn->close();
?>
