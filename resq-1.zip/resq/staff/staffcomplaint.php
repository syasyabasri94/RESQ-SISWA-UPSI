<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ced3c4;
            color: #fff;
            padding-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
        }

        .sidebar a {
            display: block;
            color: #0c0c0c;
            padding: 10px;
            text-decoration: none;
            text-align: center;
            font-size: 17px;
        }

        .sidebar a:hover {
            background-color: #8f9779;
        }


        .title {
            text-align: center;
            margin-bottom: 20px;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh;
        }
        .dashboard-box {
            width: 200px;
            height: 150px;
            background-color: #ced3c4;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
        .dashboard-box:hover {
            background-color: #8f9779;
        }

        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            margin-top: 0px;
        }

        .logo img {
            width: 45px;
            margin-right: 10px;
        }

        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
            text-align: center;
            width: 80%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }

        .complaint-table {
            margin-top: 50px;
        }

        .content-table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 18px;
            text-align: left;
        }

        .content-table th,
        .content-table td {
            padding: 12px 15px;
            border: 1px solid #ddd;
        }

        .content-table th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }

        .content-table tbody tr {
            border-bottom: 1px solid #ddd;
        }

        .content-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .content-table tbody tr:last-of-type {
            border-bottom: 2px solid #ced3c4;
        }

        .content-table img {
            max-width: 100px;
        }
    </style>
</head>
<body>
<?php
require '../mysqlconnection.php';

session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/mainpage.html");
    exit();
}

$staffId = $_SESSION['staff_id'];

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['resolve'])) {
    $complaintId = intval($_POST['complaint_id']); // Sanitize input
    $staffId = intval($_SESSION['staff_id']); // Sanitize input

    // Prepare SQL statement with direct variable insertion
    $sql = "UPDATE complaint SET Remark='resolved', Staff_ID=$staffId WHERE Complaint_ID=$complaintId";
    
    if ($conn->query($sql) === TRUE) {
        echo "Complaint resolved successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}


include 'layout/header.php'; 

?>

<div class="content">
    <div class="title">
        <h1>Complaints</h1>
    </div>

    <div class="complaint-table">
        <table class="content-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Remark</th>
                    <th>Image</th>
                    <th>Date</th>
                    <th>Student Name</th>
                    <th>Staff Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                // Retrieve role from session
                $role = $_SESSION['role'];
                $staff_id = $_SESSION['staff_id']; // For staff-specific filtering
                
                // Connect to the database
                require '../mysqlconnection.php';
                $conn = new mysqli($servername, $username, $password, $database);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Define the SQL query based on the role
                if ($role === 'admin') {
                    // Admins can see all complaints
                    $sql = "SELECT c.*, s.Name as Student_Name, st.Name as Staff_Name
                            FROM complaint c
                            JOIN student s ON c.Student_ID = s.Student_ID
                            LEFT JOIN staff st ON c.Staff_ID = st.Staff_ID";
                } else {
                    // Staff can only see complaints associated with their hostel
                    $sql = "SELECT c.*, s.Name as Student_Name, st.Name as Staff_Name,h.Hostel_ID,st.staff_ID
                            FROM complaint c
                            JOIN student s ON c.Student_ID = s.Student_ID
                            JOIN placement p ON c.Student_ID = p.Student_ID
                            JOIN room r ON p.Room_ID = r.Room_ID
                            JOIN hostel h ON r.Hostel_ID = h.Hostel_ID
                            JOIN staff st ON h.Hostel_ID = st.hostel_id
                            WHERE st.Staff_ID = ?";
                }

                if ($role === 'admin') {
                    $result = $conn->query($sql);
                } else {
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $staff_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                }

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row["Title"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["Description"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["Remark"]) . "</td>";
                        echo "<td><img src='" . htmlspecialchars($row["ImageURL"]) . "' alt='Complaint Image' style='max-width:100px;'></td>";
                        echo "<td>" . htmlspecialchars($row["Date"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["Student_Name"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["Staff_Name"]) . "</td>";
                        echo "<td>";
                        if ($row["Remark"] != 'resolved') {
                            echo "<form method='POST' action='staffcomplaint.php'>";
                            echo "<input type='hidden' name='complaint_id' value='" . htmlspecialchars($row["Complaint_ID"]) . "'>";
                            echo "<button type='submit' name='resolve'>Resolve</button>";
                            echo "</form>";
                        } else {
                            echo "Resolved";
                        }
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No complaints found</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
