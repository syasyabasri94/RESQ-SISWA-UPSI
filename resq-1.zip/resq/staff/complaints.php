<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .back-button {
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .back-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <button class="back-button" onclick="window.location.href='staffhomepage.php'">Back</button>
        <h2>Complaints</h2>
        <table>
            <thead>
                <tr>
                    <th>Complaint ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Remark</th>
                    <th>Student ID</th>
                    <th>Staff ID</th>
                </tr>
            </thead>
            <tbody>
            <?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection parameters
require '../mysqlconnection.php';

// Create a new database connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get type from URL
$type = isset($_GET['type']) ? $_GET['type'] : 'total';

// SQL to retrieve complaints data based on type
if ($type == 'resolved') {
    $sql = "SELECT * FROM complaint WHERE Remark = 'resolved'";
} elseif ($type == 'open') {
    $sql = "SELECT * FROM complaint WHERE Remark = 'open'";
} else {
    $sql = "SELECT * FROM complaint";
}

$result = $conn->query($sql);

if (!$result) {
    echo "Error executing query: " . $conn->error;
} elseif ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['Complaint_ID'] ?? '') . "</td>
                <td>" . htmlspecialchars($row['Title'] ?? '') . "</td>
                <td>" . htmlspecialchars($row['Description'] ?? '') . "</td>
                <td>" . htmlspecialchars($row['Remark'] ?? '') . "</td>
                <td>" . htmlspecialchars($row['Student_ID'] ?? '') . "</td>
                <td>" . htmlspecialchars($row['Staff_ID'] ?? '') . "</td>
              </tr>";
    }
    
} else {
    echo "<tr><td colspan='6'>No complaints found</td></tr>";
}

// Close the database connection after all operations are done
$conn->close();
?>

            </tbody>
        </table>
    </div>
</body>
</html>
