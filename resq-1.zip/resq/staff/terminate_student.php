<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/mainpage.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    require '../mysqlconnection.php';
    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $student_id = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;

    $sql = "UPDATE placement SET Status = 3 WHERE Student_ID = $student_id AND Status = 1";
if ($conn->query($sql) === TRUE) {
    echo "Student terminated successfully.";
} else {
    echo "Error terminating student.";
}

    $stmt->close();
    $conn->close();
}
?>
