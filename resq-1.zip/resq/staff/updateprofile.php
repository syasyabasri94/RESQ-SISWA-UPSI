<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['staff_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

$staffId = $_SESSION['staff_id'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$image = isset($_FILES['image']) ? $_FILES['image'] : null;

require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Sanitize input data to prevent SQL injection
$staffId = $conn->real_escape_string($staffId);
$name = $conn->real_escape_string($name);
$phone = $conn->real_escape_string($phone);
$email = $conn->real_escape_string($email);

if ($image && $image['size'] > 0) {
    $imageData = $conn->real_escape_string(file_get_contents($image['tmp_name']));
    $sql = "UPDATE staff SET Name = '$name', Phone = '$phone', Email = '$email', Image = '$imageData' WHERE Staff_ID = '$staffId'";
} else {
    $sql = "UPDATE staff SET Name = '$name', Phone = '$phone', Email = '$email' WHERE Staff_ID = '$staffId'";
}

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error updating profile: ' . $conn->error]);
}

$conn->close();
?>
