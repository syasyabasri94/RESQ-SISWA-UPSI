<?php
// Connect to the database
require '../mysqlconnection.php';

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if ID is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT Avatar FROM staff WHERE staff_id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        header("Content-Type: image/jpeg"); // Adjust based on your image type
        echo $row['Avatar'];
    } else {
        header("HTTP/1.0 404 Not Found");
        echo "Image not found";
    }
} else {
    header("HTTP/1.0 400 Bad Request");
    echo "No ID provided";
}

$conn->close();
?>
