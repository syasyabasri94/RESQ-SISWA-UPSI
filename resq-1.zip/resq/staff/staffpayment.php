<?php
session_start();
if (!isset($_SESSION['staff_id'])) {
    header("Location: /fyp/mainpage.html");
    exit();
}

require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle accept payment action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accept_payment'])) {
    $paymentId = intval($_POST['payment_id']); // Sanitize input
    $updateSql = "UPDATE payment SET Status = 1 WHERE Payment_ID = $paymentId";
    
    if ($conn->query($updateSql) === TRUE) {
        echo "Payment accepted successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch user role from session
$role = $_SESSION['role'];
$staff_id = $_SESSION['staff_id']; // For staff-specific filtering

// Fetch and filter payment data based on date range if provided
$startDate = isset($_POST['start_date']) ? $conn->real_escape_string($_POST['start_date']) : '';
$endDate = isset($_POST['end_date']) ? $conn->real_escape_string($_POST['end_date']) : '';

if ($role === 'admin') {
    // Admin can view all payments
    if ($startDate && $endDate) {
        $sql = "SELECT payment.Payment_ID, payment.Total, payment.Description, payment.PayDate, payment.PayTime, payment.Status, payment.ImageURL, student.Name
                FROM payment
                INNER JOIN placement ON payment.Placement_ID = placement.Placement_ID
                INNER JOIN student ON placement.Student_ID = student.Student_ID
                WHERE payment.PayDate BETWEEN '$startDate' AND '$endDate'";
    } else {
        $sql = "SELECT payment.Payment_ID, payment.Total, payment.Description, payment.PayDate, payment.PayTime, payment.Status, payment.ImageURL, student.Name
                FROM payment
                INNER JOIN placement ON payment.Placement_ID = placement.Placement_ID
                INNER JOIN student ON placement.Student_ID = student.Student_ID";
    }
} else {
    // Staff can only view payments associated with their hostel
    if ($startDate && $endDate) {
        $sql = "SELECT payment.Payment_ID, payment.Total, payment.Description, payment.PayDate, payment.PayTime, payment.Status, payment.ImageURL, student.Name
                FROM payment
                INNER JOIN placement ON payment.Placement_ID = placement.Placement_ID
                INNER JOIN student ON placement.Student_ID = student.Student_ID
                JOIN room ON placement.Room_ID = room.Room_ID
                JOIN hostel ON room.Hostel_ID = hostel.Hostel_ID
                JOIN staff ON staff.hostel_id = hostel.Hostel_ID
                WHERE staff.Staff_ID = $staff_id AND payment.PayDate BETWEEN '$startDate' AND '$endDate'";
    } else {
        $sql = "SELECT payment.Payment_ID, payment.Total, payment.Description, payment.PayDate, payment.PayTime, payment.Status, payment.ImageURL, student.Name
                FROM payment
                INNER JOIN placement ON payment.Placement_ID = placement.Placement_ID
                INNER JOIN student ON placement.Student_ID = student.Student_ID
                JOIN room ON placement.Room_ID = room.Room_ID
                JOIN hostel ON room.Hostel_ID = hostel.Hostel_ID
                JOIN staff ON staff.hostel_id = hostel.Hostel_ID
                WHERE staff.Staff_ID = $staff_id";
    }
}

$result = $conn->query($sql);

$paymentData = [];
while ($row = $result->fetch_assoc()) {
    $paymentData[] = $row;
}

$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #ced3c4;
            color: #fff;
            padding-top: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
        }
        .sidebar a {
            display: block;
            color: #0c0c0c;
            padding: 10px;
            text-decoration: none;
            text-align: center;
            font-size: 17px;
        }
        .sidebar a:hover {
            background-color: #8f9779;
        }
        .content {
            margin-left: 300px;
            padding: 30px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .title {
            text-align: center;
            margin-bottom: 20px;
            width: 100%;
        }
        .dashboard-box {
            width: 200px;
            height: 150px;
            background-color: #ced3c4;
            margin: 20px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            color: #fff;
            text-decoration: none;
        }
        .dashboard-box:hover {
            background-color: #8f9779;
        }
        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 40px;
            margin-top: 0px;
        }
        .logo img {
            width: 45px;
            margin-right: 10px;
        }
        .logout-btn {
            background-color: #f44336;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 10px;
            text-align: center;
            width: 30%;
            margin-top: auto;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
        .bottom-logout-btn {
            margin-bottom: 40px;
        }

        .header-logo img {
            width: 100px;
        }

        section {
            margin-bottom: 20px;
            width: 100%;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #ddd;

        }
        th, td, tr {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        table th, table td {
            padding: 8px;
            border: 2px solid #ccc; /* 1px solid border around each cell */
            font-weight: bold; /* Makes text inside cells bold */

        }

        table th {
            background-color: #f0f0f0; /* Optional: Background color for header cells */
            font-weight: bold; /* Optional: Makes header cells bold */
        }


        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .fees-data, .fees-status, .complaints-data {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .complaints-data p {
            font-weight: bold;
        }
        footer {
            background-color: #f0f0f0;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            margin-left: 250px;
        }
        .filter-form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<?php 
include 'layout/header.php'; 
?>

    <main>
        <section class="payments">
            <h2>All Payments</h2>

            <form method="POST" action="staffpayment.php" class="filter-form">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
                <button type="submit">Filter</button>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>Total</th>
                        <th>Description</th>
                        <th>Pay Date</th>
                        <th>Pay Time</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Student Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $status='none';
                    
                    if (count($paymentData) > 0) {
                        foreach ($paymentData as $payment) {
                            if ($payment['Status']=='1'){
                                $status ='APPROVED';
                            }
                            else{
                                $status ='PENDING';
        
                            }
                            echo "<tr>
                                    <td>" . htmlspecialchars($payment['Total']) . "</td>
                                    <td>" . htmlspecialchars($payment['Description']) . "</td>
                                    <td>" . htmlspecialchars($payment['PayDate']) . "</td>
                                    <td>" . htmlspecialchars($payment['PayTime']) . "</td>
                                    <td>" . htmlspecialchars($status) . "</td>
                                    <td><a href='" . htmlspecialchars($payment['ImageURL']) . "' target='_blank'>View Image</a></td>
                                    <td>" . htmlspecialchars($payment['Name']) . "</td>
                                    <td>
                                        <form method='POST' action='staffpayment.php'>
                                            <input type='hidden' name='payment_id' value='" . htmlspecialchars($payment['Payment_ID']) . "'>
                                            <button type='submit' name='accept_payment'>Accept</button>
                                        </form>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No payment data available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>
