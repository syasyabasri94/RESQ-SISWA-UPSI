<?php
session_start();

// Include the database connection file
require 'mysqlconnection.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create a new database connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve and sanitize form data
    $formUsername = $conn->real_escape_string($_POST['username']);
    $formPassword = $_POST['password'];

    // Query to fetch user data from the student table
    $sqlStudent = "SELECT * FROM student WHERE stdemail = '$formUsername'";
    $resultStudent = $conn->query($sqlStudent);

    // Query to fetch user data from the admin table
    $sqlStaff = "SELECT * FROM admin WHERE adminname = '$formUsername'";
    $resultStaff = $conn->query($sqlStaff);

    // Handle student login
    if ($resultStudent->num_rows == 1) {
        $userStudent = $resultStudent->fetch_assoc();

        // Verify password
        if ($formPassword== $userStudent['stdpass']) {
            // Set session variables for student
            $_SESSION['username'] = $userStudent['stdemail'];
            $_SESSION['userid'] = $userStudent['stdid'];
            $_SESSION['student_name'] = $userStudent['stdname'];

            // Close the database connection
            $conn->close();

            // Redirect to student home page
            header("Location: student/home.php");
            exit;
        } else {
            // Invalid password
            header("Location: login.html?error=password");
            exit;
        }
    }

    // Handle staff login
    elseif ($resultStaff->num_rows == 1) {
        $userStaff = $resultStaff->fetch_assoc();

        // Verify password
        if ($formPassword == $userStaff['Password']) {
            // Set session variables for staff
            $_SESSION['username'] = $userStaff['adminname'];
            $_SESSION['staff_id'] = $userStaff['adminid'];

            // Close the database connection
            $conn->close();

            // Redirect based on user role
            header("Location: staff/staffhomepage.php");
            exit;
        } else {
            // Invalid password
            header("Location: login.html?error=password");
            exit;
        }
    } else {
        // User not found
        header("Location: login.html?error=user");
        exit;
    }

    // Close the database connection
    $conn->close();
}
?>
