<?php
require 'mysqlconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];


    // Check if email already exists
    $email_check_query = $conn->query("SELECT * FROM student WHERE stdemail = '$email'");
    if ($email_check_query->num_rows > 0) {
        $error = "Email already exists.";
    } else {
        $sql = "INSERT INTO student (stdname, stdemail, stdphone, stdpass, status) 
        VALUES ('$fullname', '$email', '$phone', '$password', 'ACTIVE')";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['success'] = "Registration successful. Please log in.";
            header("Location: login.html");
            exit();
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">

    <body style="background-color: rgb(179, 179, 179);">
    <div class="container" style="padding-top: 100px;">
    <div class="row justify-content-center" >
        <div class="col-md-6">
            <div class="card my-5">
                <div class="card-body" style="background-color: #677088; color: white;">
                    <h2 class="card-title text-center">Register</h2>
                    <?php if (isset($error)) : ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['success'])) : ?>
                        <div class="alert alert-success">
                            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        </div>
                    <?php endif; ?>
    <form method="POST" action="">
    <div class="form-group">
        <label for="fullname">Full Name:</label>
        <input type="text" class="form-control" id="fullname" name="fullname" required>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email" required>
    </div>
    <div class="form-group">
        <label for="phone">Phone Number:</label>
        <input type="phone" class="form-control" id="phone" name="phone" required>
    </div>
    <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <div class="text-center">
    <button class="btn btn-light" type="submit" style="background-color: white; color: #000000;">Register</button>
</div>
    </form>

                </div>
            </div>
        </div>
    </div>
</div>
</body>
