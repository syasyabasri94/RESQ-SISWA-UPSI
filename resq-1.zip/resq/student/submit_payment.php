<?php
session_start();

// Set the timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $placement_id = $_POST['placement_id'];
    $description = $_POST['description'];
    $amount = (float)$_POST['amount']; // Cast to float to ensure proper type handling
    $receiptPath = handleImageUpload(); // Handle the image upload and get the path
    $status = 2; // Define status here

    // Check if the receipt path is correctly set
    if ($receiptPath === false) {
        echo "File upload failed.<br>";
        exit;
    }

    // Prepare the SQL statement with placeholders
    $sql = "INSERT INTO payment (Placement_ID, Description, Total, ImageURL, Status) 
            VALUES ('$placement_id', '$description', '$amount', '$receiptPath', '$status')";

    // Execute and check for errors
    if ($conn->query($sql) === TRUE) {
        header("Location: payment.php?success=true");
        exit();
    } else {
        echo "Error: " . $conn->error . "<br>";
    }

    $conn->close();
}

function handleImageUpload() {
    $receiptDir = "../student/receipt/";
    $receiptName = basename($_FILES['receipt']['name']);
    $receiptPath = $receiptDir . $receiptName;

    if (!file_exists($receiptDir)) {
        mkdir($receiptDir, 0777, true);
    }

    if (file_exists($receiptPath)) {
        $receiptName = time() . '_' . $receiptName;  // Append time to filename to avoid collisions
        $receiptPath = $receiptDir . $receiptName;
    }

    if (!move_uploaded_file($_FILES['receipt']['tmp_name'], $receiptPath)) {
        return false;
    }

    return $receiptPath;
}
?>
