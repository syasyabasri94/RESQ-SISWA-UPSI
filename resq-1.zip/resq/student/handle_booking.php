<?php

session_start();

// Database connection
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$startDate = $_POST['date'];
$duration = intval($_POST['duration']);
$totalAmount = floatval($_POST['totalAmount']);
$roomid = intval($_POST['roomid']);
$userid = intval($_POST['userid']);

// Convert startDate to MySQL date format
$formattedStartDate = date('Y-m-d', strtotime($startDate));

// Calculate balance (total amount for the duration)
$balance = $totalAmount ;

// Insert data into the database
$sql = "INSERT INTO placement (Date, StartDate, Duration, Total, Balance, Room_ID, Student_ID) 
        VALUES (CURRENT_DATE, '$formattedStartDate', $duration, 0, $balance, $roomid, $userid)";

if ($conn->query($sql) === TRUE) {
    // Decrement room capacity
    $updateSql = "UPDATE room SET Capacity = Capacity - 1 WHERE Room_ID = $roomid";

    if ($conn->query($updateSql) === TRUE) {
        // Return JSON response
        echo json_encode(['success' => true, 'message' => 'Booking successful!']);
    } else {
        echo json_encode(['success' => false, 'message' => "Error updating room capacity: " . $conn->error]);
    }
} else {
    // Return JSON response for error
    echo json_encode(['success' => false, 'message' => "Error executing statement: " . $conn->error]);
}

// Close connection
$conn->close();
exit;
?>
