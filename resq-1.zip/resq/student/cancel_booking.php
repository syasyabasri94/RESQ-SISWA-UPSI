<?php
// Check if placementId is set and is a valid integer
if(isset($_POST['placementId']) && filter_var($_POST['placementId'], FILTER_VALIDATE_INT)) {
    // Database connection
    require '../mysqlconnection.php';
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve Room_ID associated with the placement
    $placementId = $_POST['placementId'];
    $sql_select_room = "SELECT Room_ID FROM placement WHERE Placement_ID = $placementId";
    $result = $conn->query($sql_select_room);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $roomId = $row['Room_ID'];

        // Update Capacity column in the room table
        $sql_update_capacity = "UPDATE room SET Capacity = Capacity + 1 WHERE Room_ID = $roomId";
        if ($conn->query($sql_update_capacity) === TRUE) {
            // Prepare SQL statement to delete the booking record
            $sql_delete = "DELETE FROM placement WHERE Placement_ID = $placementId";
            
            if ($conn->query($sql_delete) === TRUE) {
                // Return success response
                echo "Booking record deleted successfully!";
            } else {
                // Return error response
                echo "Error deleting booking record: " . $conn->error;
            }
        } else {
            echo "Error updating room capacity: " . $conn->error;
        }
    } else {
        echo "No room found for the given placement ID!";
    }

    // Close connection
    $conn->close();

    // Redirect back to room.php
    header("Location: ../student/room.php");
    exit();
} else {
    // Return error if placementId is not set or not valid
    echo "Invalid placement ID!";
}
?>

