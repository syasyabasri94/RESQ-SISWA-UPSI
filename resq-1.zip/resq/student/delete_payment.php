<?php
session_start();

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the payment ID from the query string
$payment_id = intval($_GET['payment_id']); // Ensure the input is an integer

// Delete the payment from the database
$sql = "DELETE FROM payment WHERE Payment_ID = $payment_id";

if ($conn->query($sql) === TRUE) {
    // Redirect to the payment page with a success message
    header("Location: payment.php?delete_success=true");
    exit();
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
