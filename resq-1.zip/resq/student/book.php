<?php
require("../library/config.php");
session_start();

$username = $_SESSION['username'];
$userid = $_SESSION['userid'];

function newConnectionDB() {
    require '../mysqlconnection.php';
    $conn = new mysqli($servername, $username, $password, $database);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    return $conn;
}

// Establish a new database connection
$conn = newConnectionDB();

// Fetch the gender of the logged-in student
$gender_query = "SELECT Gender FROM student WHERE Student_ID = ?";
$gender_stmt = $conn->prepare($gender_query);
$gender_stmt->bind_param("i", $userid);
$gender_stmt->execute();
$gender_result = $gender_stmt->get_result();
$gender_data = $gender_result->fetch_assoc();
$gender = $gender_data['Gender'];
$gender_stmt->close();

// Check if the URL contains a value for $hid
$hid = isset($_GET['hid']) ? $_GET['hid'] : '';

// Initialize variables for filtering
$filter_hostel_id = isset($_GET['hostel_id']) ? $_GET['hostel_id'] : '';
$filter_floor = isset($_GET['floor']) ? $_GET['floor'] : '';
$filter_house_no = isset($_GET['house_no']) ? $_GET['house_no'] : '';
$filter_room_name = isset($_GET['room_name']) ? $_GET['room_name'] : '';

// Fetch filter options from the database
$hostels = $conn->query("SELECT Hostel_ID, Name FROM hostel");
$floors = $conn->query("SELECT DISTINCT Floor FROM room WHERE Status = 1");
$house_numbers = $conn->query("SELECT DISTINCT House_No FROM room WHERE Status = 1");
$room_names = $conn->query("SELECT DISTINCT Room_Name FROM room WHERE Status = 1");

// Construct the base SQL query with JOIN to fetch hostel names
$sql = "SELECT room.*, hostel.Name as Hostel_Name FROM room 
        JOIN hostel ON room.Hostel_ID = hostel.Hostel_ID 
        WHERE room.Status = 1";

// Add filters to the SQL query based on selected values
if ($filter_hostel_id !== '') {
    $sql .= " AND room.Hostel_ID = '$filter_hostel_id'";
}
if ($filter_floor !== '') {
    $sql .= " AND room.Floor = '$filter_floor'";
}
if ($filter_house_no !== '') {
    $sql .= " AND room.House_No = '$filter_house_no'";
}
if ($filter_room_name !== '') {
    $sql .= " AND room.Room_Name = '$filter_room_name'";
}

// If $hid is provided in the URL, filter by House_ID
if ($hid !== '') {
    $sql .= " AND room.Hostel_ID = '$hid'";
}

// Execute the query
$result = $conn->query($sql);

// Initialize an empty array to store room data
$rooms = array();

// Check if the query was successful
if ($result->num_rows > 0) {
    // Fetch each row of the result as an associative array
    while ($row = $result->fetch_assoc()) {
        // Add each room to the $rooms array
        $rooms[] = $row;
    }
}

// Close the database connection
$conn->close();
?>

<?php include 'layout/header.php'; ?>

<style>
    .header-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .filter-form select {
        margin-right: 10px;
    }

    .scrollable-table {
        max-height: 800px;
        overflow-y: auto;
    }

    .jebat-table {
        width: 100%;
        border-collapse: collapse;
    }

    .jebat-table th, .jebat-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    .jebat-table th {
        background-color: #f2f2f2;
    }

    .jebat-btn-primary {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        border-radius: 4px;
    }

    .jebat-action-col {
        width: 150px;
    }

    /* Modal styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgb(0, 0, 0);
        background-color: rgba(0, 0, 0, 0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>

<!-- Filter Dropdowns -->
<div class="header-row mb-2">
    <span>List of Rooms</span>
    <div class="filter-form">
        <form id="filterForm">
            <select id="filter_hostel_id" name="hostel_id">
                <option value="">All Hostels</option>
                <?php while ($hostel = $hostels->fetch_assoc()) { ?>
                    <option value="<?php echo $hostel['Hostel_ID']; ?>" <?php if($filter_hostel_id == $hostel['Hostel_ID']) echo 'selected'; ?>>
                        <?php echo $hostel['Name']; ?>
                    </option>
                <?php } ?>
            </select>

            <select id="filter_floor" name="floor">
                <option value="">All Floors</option>
                <?php while ($floor = $floors->fetch_assoc()) { ?>
                    <option value="<?php echo $floor['Floor']; ?>" <?php if($filter_floor == $floor['Floor']) echo 'selected'; ?>>
                        <?php echo $floor['Floor']; ?>
                    </option>
                <?php } ?>
            </select>

            <select id="filter_house_no" name="house_no">
                <option value="">All Houses</option>
                <?php while ($house = $house_numbers->fetch_assoc()) { ?>
                    <option value="<?php echo $house['House_No']; ?>" <?php if($filter_house_no == $house['House_No']) echo 'selected'; ?>>
                        <?php echo $house['House_No']; ?>
                    </option>
                <?php } ?>
            </select>

            <select id="filter_room_name" name="room_name">
                <option value="">All Rooms</option>
                <?php while ($room = $room_names->fetch_assoc()) { ?>
                    <option value="<?php echo $room['Room_Name']; ?>" <?php if($filter_room_name == $room['Room_Name']) echo 'selected'; ?>>
                        <?php echo $room['Room_Name']; ?>
                    </option>
                <?php } ?>
            </select>
        </form>
    </div>
</div>

<!-- Room Table -->
<div class="scrollable-table">
    <table class="jebat-table">
        <thead>
            <tr>
                <th>Hostel Name</th>
                <th>Floor</th>
                <th>House Number</th>
                <th>Room</th>
                <th>Capacity</th>
                <th class="jebat-action-col">Action</th>
            </tr>
        </thead>
        <tbody id="roomList">
            <?php if (empty($rooms)) { ?>
                <tr>
                    <td colspan="6">No rooms found</td>
                </tr>
            <?php } else { ?>
                <?php foreach ($rooms as $room) { ?>
                    <tr>
                        <td><?php echo $room['Hostel_Name']; ?></td>
                        <td><?php echo $room['Floor']; ?></td>
                        <td><?php echo $room['House_No']; ?></td>
                        <td><?php echo $room['Room_Name']; ?></td>
                        <td><?php echo $room['Capacity']; ?></td>
                        <td>
                            <button class="jebat-btn-primary" onclick="bookRoom(<?php echo $room['Room_ID']; ?>)">Book Now</button>
                        </td>
                    </tr>
                <?php } ?>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Hidden Form for Booking Data -->
<form id="bookingForm" method="post" style="display: none;">
    <input type="hidden" name="roomid" id="roomid" value="">
    <input type="hidden" name="userid" id="userid" value="<?php echo $userid; ?>">
    <input type="hidden" name="date" id="date" value="">
    <input type="hidden" name="duration" id="duration" value="">
    <input type="hidden" name="totalAmount" id="totalAmount" value="">
</form>

<!-- Modal HTML -->
<div id="bookingModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Book Room</h2>
        <form id="modalBookingForm">
            <label for="modalBookingDate">Start Date:</label>
            <input type="date" id="modalBookingDate" name="date" required><br><br>
            <label for="modalBookingDuration">Duration (months):</label>
            <input type="number" id="modalBookingDuration" name="duration" required><br><br>
            <p>Total Cost: RM <span id="totalCost">0.00</span></p>
            <button type="submit" class="jebat-btn-primary">Submit Booking</button>
        </form>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    var today = new Date().toISOString().split('T')[0];
    document.getElementById("modalBookingDate").setAttribute('min', today);
});
</script>


<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filterForm');
    filterForm.addEventListener('change', function() {
        filterForm.submit();
    });
    
    // Modal variables
    const modal = document.getElementById("bookingModal");
    const span = document.getElementsByClassName("close")[0];
    const modalBookingForm = document.getElementById("modalBookingForm");
    const totalCostElement = document.getElementById("totalCost");

    // Close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Handle form submission
    modalBookingForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const bookingDate = document.getElementById('modalBookingDate').value;
        const bookingDuration = document.getElementById('modalBookingDuration').value;
        const bookingTotalAmount = bookingDuration * 130;

        if (bookingDate && bookingDuration) {
            const form = document.getElementById('bookingForm');
            document.getElementById('date').value = bookingDate;
            document.getElementById('duration').value = bookingDuration;
            document.getElementById('totalAmount').value = bookingTotalAmount;
            
            const formData = new FormData(form);

            fetch('handle_booking.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });

            modal.style.display = "none";
        } else {
            alert("All fields are required.");
        }
    });

    // Update total cost on duration change
    document.getElementById('modalBookingDuration').addEventListener('input', function() {
        const bookingDuration = document.getElementById('modalBookingDuration').value;
        const bookingTotalAmount = bookingDuration * 130;
        totalCostElement.innerText = bookingTotalAmount.toFixed(2);
    });
});

function bookRoom(roomId) {
    // Display the modal
    const modal = document.getElementById("bookingModal");
    modal.style.display = "block";

    // Set the room ID for the booking
    document.getElementById('roomid').value = roomId;
}
</script>

<?php include 'layout/footer.php'; ?>
