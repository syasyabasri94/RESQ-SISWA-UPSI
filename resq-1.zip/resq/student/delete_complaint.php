<?php
session_start();

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $complaint_id = intval($_POST['complaint_id']); // Ensure the input is an integer

    // Prepare and execute delete query
    $sql = "DELETE FROM `complaint` WHERE `Complaint_ID` = $complaint_id";

    if ($conn->query($sql) === TRUE) {
        $response = ["status" => "success", "message" => "Complaint deleted successfully."];
    } else {
        $response = ["status" => "error", "message" => "Failed to delete complaint."];
    }

    $conn->close();

    echo json_encode($response);
}
?>
