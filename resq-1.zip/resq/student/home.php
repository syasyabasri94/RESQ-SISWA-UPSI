<?php 
session_start();

// Session variables
$session_username = $_SESSION['username'];
$session_name = $_SESSION['student_name'];

$userid = intval($_SESSION['userid']); // Ensure userid is an integer

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch student data for the logged-in student
$sql_student = "SELECT * FROM student WHERE stdid = $userid";
$result_student = $conn->query($sql_student);

if ($result_student) {
    $student = $result_student->fetch_assoc();
} else {
    die("Error fetching student data: " . $conn->error);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['profile_picture'];
        $fileTmpPath = $file['tmp_name'];
        $fileName = $file['name'];
        $fileSize = $file['size'];
        $fileType = $file['type'];
        $fileNameCmps = explode('.', $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        
        // Validate file extension
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($fileExtension, $allowedExtensions)) {
            // Define upload path
            $uploadPath = 'avatar/';
            $newFileName = $userid . '.' . $fileExtension; // e.g., 123.jpg
            $destPath = $uploadPath . $newFileName;

            // Move file to the upload directory
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // Update the user's profile picture in the database
                $sql = "UPDATE student SET avatar = ? WHERE stdemail = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $newFileName, $session_username);

                if ($stmt->execute()) {
                    // Reload the page to reflect changes
                    header('Location: home.php?upload_success=1');
                    exit();
                } else {
                    $error_message = "Error updating profile picture: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error_message = "Error moving uploaded file.";
            }
        } else {
            $error_message = "Invalid file type.";
        }
    } else {
        $error_message = "Error with file upload. Code: " . $_FILES['profile_picture']['error'];
    }
}


include 'layout/header.php'; 
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="section-container">
    <div class="section-title"><h2>Your Profile</h2></div>
    <div class="profile-container">
        <div class="profile-image">
        <img src="<?php echo (empty($student['avatar']) ? '../student/avatar/null.png' : '../student/avatar/' . htmlspecialchars($student['avatar'])); ?>" alt="Profile Picture">
        </div>
        <div class="details">
            <div class="details-row">
                <label class="details-label">Name:</label>
                <span class="details-value"><?php echo htmlspecialchars($session_name); ?></span>
            </div>
            <div class="details-row">
                <label class="details-label">Phone:</label>
                <span class="details-value"><?php echo !empty($student['stdphone']) ? htmlspecialchars($student['stdphone']) : '<span class="text-muted">Not Set</span>'; ?></span>
            </div>
            <div class="details-row">
                <label class="details-label">Email:</label>
                <span class="details-value"><?php echo !empty($student['stdemail']) ? htmlspecialchars($student['stdemail']) : '<span class="text-muted">Not Set</span>'; ?></span>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="main-content">
        <!-- Profile Section -->
        <div class="profile-card">
            <!-- Profile Header -->
            <div class="profile-header">
                <div>
                    <h3><?php echo htmlspecialchars($session_name); // Dynamic user name ?></h3>
                    <!-- Form for Uploading Picture -->
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="file" name="profile_picture" accept="image/*">
                        <button type="submit">Upload New Picture</button>
                    </form>
                </div>
            </div>


            <form method="POST" action="update_profile.php">
    <!-- Full Name -->
    <div class="form-group">
        <label for="first_name">Full Name</label>
        <input type="text" id="first_name" name="first_name" placeholder="Full Name" value="<?php echo !empty($student['stdname']) ? htmlspecialchars($student['stdname']) : '<span class="text-muted">Not Set</span>'; ?>">
    </div>
    <!-- Contact Information -->
    <div class="form-group">
        <label for="phone">Phone Number</label>
        <input type="text" id="phone" name="phone" placeholder="Phone Number" value="<?php echo !empty($student['stdphone']) ? htmlspecialchars($student['stdphone']) : '<span class="text-muted">Not Set</span>'; ?>">
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Email" value="<?php echo !empty($student['stdemail']) ? htmlspecialchars($student['stdemail']) : '<span class="text-muted">Not Set</span>'; ?>">
    </div>
    <!-- Password -->
    <div class="form-group">
        <label for="current_password">Current Password</label>
        <input type="password" id="current_password" name="current_password" placeholder="Current Password">
    </div>
    <div class="form-group">
        <label for="new_password">New Password</label>
        <input type="password" id="new_password" name="new_password" placeholder="New Password">
    </div>

    <!-- Volunteering History -->
    <div class="form-group">
        <label for="volunteering_history">Volunteering History</label>
        <input type="text" id="volunteering_history" placeholder="Volunteering History" readonly value="<?php echo htmlspecialchars($volunteering_history); // Dynamic value ?>">
    </div>

    <!-- Account Security -->
    <div class="profile-footer">
        <button type="button" class="log-out-btn">Log Out</button>
        <button type="button" class="delete-account-btn">Delete My Account</button>
    </div>
</form>

        </div>
    </div>
</div>


<?php include 'layout/footer.php'; ?>

<style>
        
        .container {
            display: flex;
        }
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #677088;
            color: white;
        }
        .profile-card {
            background-color: #8c92ac;
            padding: 20px;
            border-radius: 15px;
            width: 100%;
            display: flex;
            flex-direction: column;
        }
        .profile-card input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .profile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .profile-header img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }
        .profile-header button {
            background-color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        .profile-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .profile-footer button {
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }
        .log-out-btn {
            background-color: #555;
            color: white;
        }
        .delete-account-btn {
            background-color: red;
            color: white;
        }
    </style>
    <style>
    .section-container {
        padding: 20px;
        background-color: #8c92ac;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        margin-top: 20px;
        margin-bottom: 20px;
    }

    .section-title {
        font-size: 24px;
        color: white;
        margin-bottom: 10px;
        position: relative;
    }

    .section-title:after {
        content: "";
        position: absolute;
        left: 0;
        bottom: -10px;
        width: 100%;
        height: 2px;
        background-color: #aaa;
    }

    .profile-container {
        display: flex;
        align-items: center;
    }

    .profile-image img {
        width: 200px;
        height: 200px;
        object-fit: cover;
        border: 3px solid #ddd;
    }

    .details {
        margin-left: 20px;
        color: white;
        flex-grow: 1;
    }

    .details-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin: 10px 0;
    }

    .details-label {
        font-weight: bold;
        color: white;
        width: 30%;
    }

    .details-value {
        width: 70%;
        text-align: left;
    }

    .text-muted {
        color: #6c757d;
        font-style: italic;
    }

    .complaints-container {
        padding: 20px;
        background-color: #f4f4f4;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        margin-top: 20px;
        margin-bottom: 20px;
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center; /* Centers text in table cells */
    }

    th {
        background-color: #666;
        color: white;
    }

    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.7); /* Black w/ opacity */
    }

    /* Modal Content (image) */
    .modal-content {
        margin: auto;
        display: block;
        width: 80%;
        max-width: 700px;
        margin-top: 150px;
    }

    /* Add Animation */
    .modal-content {    
        -webkit-animation-name: zoom;
        -webkit-animation-duration: 0.6s;
        animation-name: zoom;
        animation-duration: 0.6s;
    }

    @-webkit-keyframes zoom {
        from {-webkit-transform:scale(0)} 
        to {-webkit-transform:scale(1)}
    }

    @keyframes zoom {
        from {transform:scale(0)} 
        to {transform:scale(1)}
    }

    /* The Close Button */
    .close {
        position: absolute;
        top: 15px;
        right: 150px;
        color: #f1f1f1;
        font-size: 40px;
        font-weight: bold;
        transition: 0.3s;
        margin-top: 80px;
    }

    .close:hover,
    .close:focus {
        color: #bbb;
        text-decoration: none;
        cursor: pointer;
    }

</style>