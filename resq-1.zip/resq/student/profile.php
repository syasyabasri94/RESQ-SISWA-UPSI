<?php 
session_start();

// Session variables
$session_username = $_SESSION['username'];
$userid = $_SESSION['userid'];

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data
$sql = "SELECT Username, Name, Matric_No, Email, Phone_No, Age, Faculty, Program, Gender, Avatar FROM student WHERE Student_ID = $userid";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();

    $faculty = htmlspecialchars($student['Faculty']);
    $program = htmlspecialchars($student['Program']);
} else {
    echo "No records found.";
}

include 'layout/header.php'; 
?>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

<?php
if (isset($_GET['status'])) {
    $swal_message = 'Profile Updated Successfully!';
    $swal_title = 'Success!';
    $swal_icon = 'success';

    switch ($_GET['status']) {
        case 'success':
            // No need to change default message
            break;
        case 'emailerror':
            $swal_message = 'Email already in use. Please use a different email.';
            $swal_title = 'Error!';
            $swal_icon = 'error';
            break;
        case 'matricerror':
            $swal_message = 'Matric No already in use. Please use a different Matric No.';
            $swal_title = 'Error!';
            $swal_icon = 'error';
            break;
        case 'avatarerror':
            $swal_message = 'Error uploading avatar. Please try again.';
            $swal_title = 'Error!';
            $swal_icon = 'error';
            break;
        default:
            $swal_message = 'An unexpected error occurred.';
            $swal_title = 'Error!';
            $swal_icon = 'error';
    }

    echo "<script type='text/javascript'>
            window.onload = function() {
                Swal.fire({
                    title: '" . $swal_title . "',
                    text: '" . $swal_message . "',
                    icon: '" . $swal_icon . "',
                    confirmButtonText: 'OK'
                });
            };
          </script>";
}
?>

<!-- Custom styles -->
<style>
    .profile-update-container {
        padding: 20px;
        margin-top: 30px;
        background-color: #f7f7f7;
        border-radius: 5px;
    }
    .profile-update-label {
        font-weight: bold;
    }
    .profile-update-input, .profile-update-select {
        padding: 8px;
        margin-top: 5px;
        margin-bottom: 15px;
        width: 100%;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .profile-avatar {
        display: block;
        margin: 10px auto 20px;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        object-fit: cover;
    }
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="container profile-update-container">
    <h2 class="mb-3">Update Your Profile</h2>
    <img src="<?php echo (empty($student['Avatar']) ? '../student/avatar/null.png' : htmlspecialchars($student['Avatar'])); ?>" alt="Profile Avatar" class="profile-avatar">
    <form action="submit-profile.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="username" class="form-label profile-update-label">Username</label>
            <input type="text" class="form-control profile-update-input" id="username" name="Username" value="<?php echo htmlspecialchars($student['Username']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="name" class="form-label profile-update-label">Name</label>
            <input type="text" class="form-control profile-update-input" id="name" name="Name" value="<?php echo htmlspecialchars($student['Name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="matricNo" class="form-label profile-update-label">Matric No</label>
            <input type="text" class="form-control profile-update-input" id="matricNo" name="Matric_No" value="<?php echo htmlspecialchars($student['Matric_No']); ?>">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label profile-update-label">Email</label>
            <input type="email" class="form-control profile-update-input" id="email" name="Email" value="<?php echo htmlspecialchars($student['Email']); ?>">
        </div>
        <div class="mb-3">
            <label for="phoneNo" class="form-label profile-update-label">Phone No</label>
            <input type="text" class="form-control profile-update-input" id="phoneNo" name="Phone_No" value="<?php echo htmlspecialchars($student['Phone_No']); ?>">
        </div>
        <div class="mb-3">
            <label for="age" class="form-label profile-update-label">Age</label>
            <input type="number" class="form-control profile-update-input" id="age" name="Age" value="<?php echo htmlspecialchars($student['Age']); ?>">
        </div>
        <div class="mb-3">
            <label for="faculty" class="form-label profile-update-label">Faculty</label>
            <select class="form-select profile-update-select" id="faculty" name="Faculty" onchange="updateProgramOptions()">
                <option value="">Select Faculty</option>
                <option value="FTKEK" <?php echo ($faculty == 'FTKEK') ? 'selected' : ''; ?>>FTKEK</option>
                <option value="FTKE" <?php echo ($faculty == 'FTKE') ? 'selected' : ''; ?>>FTKE</option>
                <option value="FTKM" <?php echo ($faculty == 'FTKM') ? 'selected' : ''; ?>>FTKM</option>
                <option value="FTKIP" <?php echo ($faculty == 'FTKIP') ? 'selected' : ''; ?>>FTKIP</option>
                <option value="FTMK" <?php echo ($faculty == 'FTMK') ? 'selected' : ''; ?>>FTMK</option>
                <option value="FPTT" <?php echo ($faculty == 'FPTT') ? 'selected' : ''; ?>>FPTT</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="program" class="form-label profile-update-label">Program</label>
            <select class="form-select profile-update-select" id="program" name="Program">
                <!-- Program options will be populated dynamically using JavaScript -->
            </select>
        </div>
        <div class="mb-3">
            <label for="gender" class="form-label profile-update-label">Gender</label>
            <select class="form-select profile-update-select" id="gender" name="Gender">
                <option value="" selected>Choose...</option>
                <option value="Male" <?php echo ($student['Gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                <option value="Female" <?php echo ($student['Gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="avatar" class="form-label profile-update-label">Update Avatar</label>
            <input type="file" class="form-control profile-update-input" id="avatar" name="Avatar">
        </div>
        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

<script>
    const facultyPrograms = {
        FTKEK: ['BERR', 'BERE', 'BERT'],
        FTKE: ['BEEY', 'BEEA'],
        FTKM: ['BMMM', 'BMMP', 'BMMD'],
        FTKIP: ['BMIG', 'BMIF'],
        FTMK: ['BITD', 'BITC', 'BITM', 'BITZ'],
        FPTT: ['BTEC', 'BTMS', 'BTMI']
    };

    function updateProgramOptions() {
        const facultySelect = document.getElementById('faculty');
        const programSelect = document.getElementById('program');
        const selectedFaculty = facultySelect.value;
        const studentProgram = <?php echo json_encode($program); ?>;
        console.log("Selected Faculty: ", selectedFaculty);
        console.log("Student Program: ", studentProgram);

        // Clear existing options
        programSelect.innerHTML = '<option value="">Select Program</option>';

        if (selectedFaculty && facultyPrograms[selectedFaculty]) {
            facultyPrograms[selectedFaculty].forEach(program => {
                const option = document.createElement('option');
                option.value = program;
                option.text = program;
                if (program === studentProgram) {
                    option.selected = true;
                }
                programSelect.appendChild(option);
            });
        }
    }

    window.onload = function() {
        const studentFaculty = <?php echo json_encode($faculty); ?>;
        console.log("Student Faculty: ", studentFaculty);

        if (studentFaculty) {
            document.getElementById('faculty').value = studentFaculty;
            updateProgramOptions();  // Populate and set program on page load
        }
    };
</script>

<?php include 'layout/footer.php'; ?>
