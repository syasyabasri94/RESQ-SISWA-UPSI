<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userid'])) {
    // Redirect to login page if not logged in
    header('Location: login.php');
    exit;
}

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update profile data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userid = $_SESSION['userid'];

    // Handle Matric_No and email generation
    if (!empty($_POST['Matric_No'])) {
        $matric_no = strtoupper($conn->real_escape_string($_POST['Matric_No']));
        $email = strtolower($matric_no) . '@student.utem.edu.my';

        // Check if Matric_No is unique
        $query = "SELECT Student_ID FROM student WHERE Matric_No = '$matric_no' AND Student_ID != $userid";
        $result = $conn->query($query);
        if ($result->num_rows > 0) {
            header('Location: profile.php?status=matricerror');
            exit;
        }

        // Update email along with Matric_No
        $_POST['Email'] = $email;
    }

    // Prepare SQL for updating user data
    $sql = "UPDATE student SET ";
    $values = [];
    $set_clause = [];

    // Dynamically build the query based on provided fields
    foreach ($_POST as $key => $value) {
        if (!empty($value) && $key != 'Student_ID') {
            $key = $conn->real_escape_string($key);
            $value = $conn->real_escape_string($value);
            $set_clause[] = "$key = '$value'";
        }
    }

    // Handle avatar upload
    if (isset($_FILES['Avatar']) && $_FILES['Avatar']['error'] == UPLOAD_ERR_OK) {
        $tmp_name = $_FILES['Avatar']['tmp_name'];
        $avatar_name = $userid . '_' . time() . '.jpg';  // Create a unique name for the file
        $upload_dir = '../student/avatar/';

        if (move_uploaded_file($tmp_name, $upload_dir . $avatar_name)) {
            $set_clause[] = "Avatar = '" . $conn->real_escape_string($upload_dir . $avatar_name) . "'";
        } else {
            header('Location: profile.php?status=avatarerror');
            exit;
        }
    }

    // Finalize SQL
    $sql .= implode(', ', $set_clause);
    $sql .= " WHERE Student_ID = $userid";

    // Execute and check for errors
    if ($conn->query($sql)) {
        header('Location: profile.php?status=success');
        exit;
    } else {
        header('Location: profile.php?status=error');
        exit;
    }
}

$conn->close();
?>
