<?php
session_start();

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['complaintID']) && isset($_POST['updateTitle']) && isset($_POST['updateDescription'])) {
    $complaintID = $conn->real_escape_string($_POST['complaintID']);
    $title = $conn->real_escape_string($_POST['updateTitle']);
    $description = $conn->real_escape_string($_POST['updateDescription']);

    $proof = null;
    if (isset($_FILES['updateProof']) && $_FILES['updateProof']['error'] == 0) {
        $proof = 'uploads/' . basename($_FILES['updateProof']['name']);
        move_uploaded_file($_FILES['updateProof']['tmp_name'], $proof);
        $proof = $conn->real_escape_string($proof);
    }

    if ($proof) {
        $query = "UPDATE `complaint` SET `Title` = '$title', `Description` = '$description', `ImageURL` = '$proof' WHERE `ComplaintID` = $complaintID";
    } else {
        $query = "UPDATE `complaint` SET `Title` = '$title', `Description` = '$description' WHERE `ComplaintID` = $complaintID";
    }

    if ($conn->query($query) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Complaint updated successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update complaint']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}

$conn->close();
?>
