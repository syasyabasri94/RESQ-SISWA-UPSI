<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userid'])) {
    // Redirect user to login page or handle unauthorized access
    header("Location: login.php");
    exit();
}

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID from session
$userid = $_SESSION['userid'];

// Get form data
$title = $conn->real_escape_string($_POST['title']);
$description = $conn->real_escape_string($_POST['description']);

// File handling (uploading image)
$targetDir = "../student/complaint/"; // Directory where you want to save uploaded images
$fileName = basename($_FILES["proof"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

// Check if file is a valid image
$allowTypes = array('jpg', 'jpeg', 'png', 'gif');
if (!in_array($fileType, $allowTypes)) {
    echo json_encode(array("status" => "error", "message" => "Sorry, only JPG, JPEG, PNG, GIF files are allowed."));
    exit();
}

// Upload file to server
if (move_uploaded_file($_FILES["proof"]["tmp_name"], $targetFilePath)) {
    // Insert data into database
    $date = date("Y-m-d");
    $imageUrl = $conn->real_escape_string($targetFilePath); // Escape the file path
    $query = "INSERT INTO complaint (Title, Description, Remark, Date, Student_ID, Staff_ID, ImageURL) VALUES ('$title', '$description', NULL, '$date', $userid, NULL, '$imageUrl')";
    
    if ($conn->query($query) === TRUE) {
        echo json_encode(array("status" => "success", "message" => "Complaint submitted successfully."));
    } else {
        echo json_encode(array("status" => "error", "message" => "Error: " . $conn->error));
    }
} else {
    echo json_encode(array("status" => "error", "message" => "Sorry, there was an error uploading your file."));
}

// Close database connection
$conn->close();
?>

