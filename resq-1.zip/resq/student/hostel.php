<?php 
session_start();

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userid = $_SESSION['userid'];
$gender = $_SESSION['student_gender'];

// Fetch student profile completeness
$sql_check_profile = "SELECT * FROM student WHERE Student_ID = $userid";
$result_check_profile = $conn->query($sql_check_profile);
$student = $result_check_profile->fetch_assoc();

$gender = $student['Gender'];  // Fetch the gender of the student

// Check if any required field is null
$requiredFields = ['Matric_No', 'Faculty', 'Program', 'Email', 'Gender', 'Avatar'];
$incompleteProfile = false;
foreach ($requiredFields as $field) {
    if (empty($student[$field])) {
        $incompleteProfile = true;
        break;
    }
}

// Fetch placement data for the logged-in student
$sql_placement = "SELECT * FROM placement WHERE Student_ID = $userid AND Status IN (1, 2)";
$result_placement = $conn->query($sql_placement);
$placement = $result_placement->fetch_assoc();

include 'layout/header.php'; 
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<!-- Styles remain unchanged -->
<style>
    .custom-container {
        display: flex;
        flex-wrap: wrap;
        padding: 20px;
    }

    .custom-column {
        flex: 1 1 calc(33.333% - 30px);
        max-width: calc(33.333% - 30px);
        box-sizing: border-box;
        margin: 15px;
        border: 2px solid #ccc;
        border-radius: 10px;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        background-color: #fff;
        height: 400px;
    }

    .custom-column:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    .custom-image-container {
        width: 100%;
        height: 200px;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .custom-image-container img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: block;
    }

    .custom-title {
        padding: 15px;
        text-align: left;
        font-size: 1.3em;
        font-weight: bold;
        color: #333;
        flex-grow: 1;
    }

    .custom-btn {
        margin: 15px;
        padding: 10px 20px;
        border: none;
        background-color: #007BFF;
        color: white;
        cursor: pointer;
        align-self: flex-end;
        border-radius: 5px;
        transition: background-color 0.3s ease;
        font-size: 0.9em;
        text-decoration: none;
        display: inline-block;
        text-align: center;
    }

    .custom-btn:hover {
        background-color: #0056b3;
        color: white;
    }

    @media (max-width: 1200px) {
        .custom-column {
            flex: 1 1 calc(50% - 30px);
            max-width: calc(50% - 30px);
        }
    }

    @media (max-width: 768px) {
        .custom-column {
            flex: 1 1 100%;
            max-width: 100%;
        }
    }
</style>

<?php
if ($incompleteProfile) {
    echo "<script>
        Swal.fire({
            title: 'Incomplete Profile',
            text: 'Please complete your profile to proceed on this page.',
            icon: 'warning',
            confirmButtonText: 'Complete Profile'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'profile.php';
            }
        });
    </script>";
} elseif (!empty($placement)) {
    echo "<script>
        Swal.fire({
            title: 'Booking Alert',
            text: 'You already booked the hostel, please check your booking.',
            icon: 'info',
            confirmButtonText: 'Ok'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../student/room.php';
            }
        });
    </script>";
} else {
    if (empty($placement)){
        echo '<div><li class="alert alert-danger">Book your room now before there are no more rooms available!</li></div>';
    }

    // Fetch hostel data from the database
    $sql_hostel = "SELECT * FROM hostel where description like '% $gender%'";
    $result_hostel = $conn->query($sql_hostel);

    if ($result_hostel->num_rows > 0) {
        echo '<div class="custom-container">';
        while ($row = $result_hostel->fetch_assoc()) {
            $hostel_id = $row['Hostel_ID'];
            $name = $row['Name'];
            $image_data = base64_encode($row['image']);
            $image_src = 'data:image/jpeg;base64,' . $image_data;
            $hostel_gender = ($hostel_id == 2 || $hostel_id == 1 || $hostel_id == 3) ? 'Male' : 'Female';
            $description = $row['description']; 
            $status = $row['Status']; 
            
            if($status=='0'){
                
            ?>
            <div class="custom-column">
    <div class="custom-image-container">
        <img src="<?php echo $image_src; ?>" alt="Hostel Image">
    </div>
    <div class="custom-title">
        <?php echo $name; ?>
        <p style="font-weight: normal;"><?php echo "Description: " . $description; ?></p>
        <hr>
    </div>
    <?php if ($status==1) { ?>
        <a href="../student/book.php?hid=<?php echo $hostel_id; ?>" class="custom-btn">Book Now</a>
    <?php } else { ?>
        <a href="#" class="custom-btn" onclick="return false;" style="pointer-events: none; opacity: 0.5;">Unavailable</a>
    <?php } ?>
</div>
            <?php
            }else{
             
                ?>
                <div class="custom-column">
                <div class="custom-image-container">
                    <img src="<?php echo $image_src; ?>" alt="Hostel Image">
                </div>
                <div class="custom-title">
                    <?php echo $name; ?>
                    <p style="font-weight: normal;"><?php echo "Description: " . $description; ?></p>
                    <hr>
                </div>
                <a href="../student/book.php?hid=<?php echo $hostel_id; ?>" class="custom-btn">Book Now</a>
            </div>
                <?php
            }

        }
        echo '</div>';
    } else {
        echo "<p>No hostels available.</p>";
    }
}
?>

<?php include 'layout/footer.php'; ?>
