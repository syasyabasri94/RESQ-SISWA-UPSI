<?php
session_start();

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the payment ID from the query string
$payment_id = $_GET['payment_id'];

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $description = $_POST['description'];
    $amount = $_POST['amount'];

    // Handle file upload
    $target_dir = "../student/receipt/";
    $target_file = $target_dir . basename($_FILES["receipt"]["name"]);
    $upload_ok = 1;
    $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["receipt"]["tmp_name"]);
    if ($check !== false) {
        $upload_ok = 1;
    } else {
        echo "File is not an image.";
        $upload_ok = 0;
    }

    // Check file size
    if ($_FILES["receipt"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $upload_ok = 0;
    }

    // Allow certain file formats
    if ($image_file_type != "jpg" && $image_file_type != "png" && $image_file_type != "jpeg" && $image_file_type != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $upload_ok = 0;
    }

    // Check if $upload_ok is set to 0 by an error
    if ($upload_ok == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["receipt"]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES["receipt"]["name"])) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Update the payment details in the database
    $sql = "UPDATE payment SET Description = '$description', Total = $amount, ImageURL = '$target_file' WHERE Payment_ID = $payment_id";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the payment page with a success message
        header("Location: payment.php?success=true");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
