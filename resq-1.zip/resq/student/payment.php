<?php 
session_start();

$username = $_SESSION['username'];
$userid = $_SESSION['userid'];

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

include 'layout/header.php'; 

// Avoid SQL injection by ensuring $userid is properly sanitized
$userid = intval($userid);  // Cast to integer to prevent SQL injection

$sql_details2 = "SELECT * FROM placement WHERE Student_ID = $userid AND Status = 2";
$result_details2 = $conn->query($sql_details2);
$details2 = $result_details2->fetch_assoc();

$sql_details = "SELECT pl.Date, pl.StartDate, pl.Duration, pl.Total, pl.Balance, pl.Status, 
                       ro.Floor, ro.House_No, ro.Room_Name, ho.Name AS HostelName
                FROM placement pl
                JOIN room ro ON pl.Room_ID = ro.Room_ID
                JOIN hostel ho ON ro.Hostel_ID = ho.Hostel_ID
                WHERE pl.Student_ID = $userid AND pl.Status = 1";
$result_details = $conn->query($sql_details);
$details = $result_details->fetch_assoc();

// Get Placement_ID associated with the logged-in student
$sql_placement = "SELECT Placement_ID, Duration FROM placement WHERE Student_ID = $userid AND Status = 1";
$result_placement = $conn->query($sql_placement);

// If there is a placement for the student, fetch payment data
if ($result_placement->num_rows > 0) {
    $row_placement = $result_placement->fetch_assoc();
    $placement_id = intval($row_placement['Placement_ID']);  // Cast to integer
    $placement_duration = intval($row_placement['Duration']);  // Cast to integer

    // Fetch payment data associated with the placement
    $sql_payment = "SELECT * FROM payment WHERE Placement_ID = $placement_id";
    $result_payment = $conn->query($sql_payment);
} else {
    echo "No placement found for the student.";
}
?>


<style>
/* Add your CSS styles here */
.dashboard-content {
    padding: 30px;
    text-align: center;
}
.dashboard-title {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
    font-size: 24px;
}
.dashboard-section {
    border: 1px solid #ccc;
    padding: 20px;
    background-color: #f9f9f9;
    border-radius: 5px;
    width: 80%;
    margin-left: auto;
    margin-right: auto;
}
.dashboard-section h2 {
    color: #444;
    font-size: 20px;
    text-align: left;
}
.dashboard-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
    font-size: 16px;
}
.dashboard-table th, .dashboard-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}
.dashboard-table th {
    background-color: #eef;
    font-weight: bold;
}
.payment-button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 20px;
}
.payment-button:hover {
    background-color: #339c39;
}
.content {
    margin-left: auto;
    margin-right: auto;
    padding: 30px;
    text-align: center;
}
.title {
    text-align: center;
    margin-bottom: 20px;
}
.transaction-section {
    border: 1px solid #ccc;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    margin-top: 15px;
    margin-left: auto; /* Center horizontally */
    margin-right: auto;
}
.transaction-section h2 {
    margin-top: 0;
    text-align: center;
}
.transaction-section table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}
.transaction-section th, .transaction-section td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}
.transaction-section th {
    background-color: #f2f2f2;
}
.new-payment-form h2 {
    margin-top: 10px;
    text-align: center;
}
.new-payment-form {
    overflow: hidden;
    max-height: 0; /* Initially hide the form */
    opacity: 0;
    transition: max-height 0.5s ease, opacity 0.5s ease; /* Smooth transition for max-height and opacity */
    padding: 0 50px; /* Maintain padding for visual consistency when expanded */
    border: 1px solid #bab6b6;
    border-radius: 5px;
    background-color: #fff;
    display: none; /* Start with display none to handle initial page load without flash */
    margin-top: 30px;
}
.new-payment-form.expanded {
    max-height: 500px; /* Adjust max-height to the expanded form size */
    opacity: 1;
    display: block; /* Ensure it is set to block when expanding */
}
.new-payment-form label {
    display: block;
    margin-bottom: 10px;
    text-align: left;
}
.new-payment-form input[type="text"], 
.new-payment-form input[type="date"] {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    box-sizing: border-box;
}
.new-payment-form input[type="file"] {
    margin-top: 10px;
    float: left;
}
.new-payment-form button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    float: right;
}
.new-payment-form button:hover {
    background-color: #339c39;
}
/* Adjust the dropdown menu */
.new-payment-form select {
    width: calc(102% - 20px); /* Adjust width */
    padding: 8px;
    margin-bottom: 10px;
    box-sizing: border-box;
    margin-left: 0; /* Remove default margin */
    float: left; /* Align to the left */
}
/* Modal Styles */
.modal-header {
    background-color: #007bff;
    color: white;
}
.modal-title {
    margin: 0;
    line-height: 1.5;
}
.modal-body {
    padding: 20px;
}
.modal-footer {
    display: flex;
    justify-content: flex-end;
}
.modal-footer button {
    margin-left: 10px;
}
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
    if ($details2){
        ?>
<script>
    // Display SweetAlert for booking a room
    Swal.fire({
        icon: 'warning',
        title: 'Your booking has not been accepted yet',
        text: 'To continue on this page, please wait booking to be accepted.',
        showCancelButton: false,
        confirmButtonText: 'Done',
    }).then((result) => {
        // Redirect to booking page regardless of user's choice
        window.location.href = '../student/room.php';
    });
</script>
<?php
    }else if (empty($details)){
        ?>
<script>
    // Display SweetAlert for booking a room
    Swal.fire({
        icon: 'error',
        title: 'You need to book your room first',
        text: 'To continue on this page, please book your room first.',
        showCancelButton: false,
        confirmButtonText: 'Book Now',
    }).then((result) => {
        // Redirect to booking page regardless of user's choice
        window.location.href = '../student/hostel.php';
    });
</script>
<?php
}  else{      
?>

<div class="content">
    <h1 class="title">Transaction Section</h1>
    <p>Welcome to the transaction section. Here you can view your transaction history.</p>
    <br>
    <div class="dashboard-section">
        <h2>Your Placement Details</h2>
        <?php if ($details): ?>
        <table class="dashboard-table">
            <tr>
                <th>Hostel Name</th>
                <td><?= htmlspecialchars($details['HostelName']) ?></td>
            </tr>
            <tr>
                <th>Floor</th>
                <td><?= htmlspecialchars($details['Floor']) ?></td>
            </tr>
            <tr>
                <th>House Number</th>
                <td><?= htmlspecialchars($details['House_No']) ?></td>
            </tr>
            <tr>
                <th>Room Name</th>
                <td><?= htmlspecialchars($details['Room_Name']) ?></td>
            </tr>
            <tr>
                <th>Start Date</th>
                <td><?= htmlspecialchars(date("F j, Y", strtotime($details['StartDate']))) ?></td>
            </tr>
            <tr>
                <th>Duration (Months)</th>
                <td><?= htmlspecialchars($details['Duration']) ?></td>
            </tr>
            <tr>
                <th>Total Paid</th>
                <td><?= htmlspecialchars(number_format($details['Total'], 2)) ?></td>
            </tr>
            <tr>
                <th>Current Balance</th>
                <td id="balance-value"><?= htmlspecialchars(number_format($details['Balance'], 2)) ?></td>
            </tr>
            <tr>
                <th>Status</th>
                <td><?= ($details['Status'] == 1 ? 'Active' : 'Inactive') ?></td>
            </tr>
        </table>
        <?php else: ?>
        <p>No placement details found.</p>
        <?php endif; ?>
    </div>
    <div class="transaction-section">
        <h2>Transaction History</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Receipt</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                if ($result_payment->num_rows > 0) {
                    while ($row_payment = $result_payment->fetch_assoc()) {

                        $status="Pending";
                if($row_payment['Status']==1){
                    $status="Approved";
                }
                        // Assume $row_payment['PayDate'] contains the date in 'YYYY-MM-DD' format
                        $originalDate = $row_payment['PayDate'];
                        // Create a DateTime object from the original date string
                        $dateObject = new DateTime($originalDate);
                        // Reformat the date to 'DD-MM-YYYY'
                        $formattedDate = $dateObject->format('d-m-Y');
                        echo "<tr>";
                        echo "<td>" . $formattedDate . "</td>";
                        echo "<td>" . $row_payment['PayTime'] . "</td>";
                        echo "<td>" . $row_payment['Description'] . "</td>";
                        echo "<td>" . $row_payment['Total'] . "</td>";
                        echo "<td>$status</td>";
                        echo "<td><a href='" . $row_payment['ImageURL'] . "' target='_blank'>View Receipt</a></td>";
                        
                        // Check the status and disable buttons if status is 1
                        $disabled = $row_payment['Status'] == 1 ? 'disabled' : '';
                
                        echo "<td>";
                        echo "<button onclick='openEditModal(this)' data-id='{$row_payment['Payment_ID']}' data-description='{$row_payment['Description']}' data-amount='{$row_payment['Total']}' data-receipt-url='{$row_payment['ImageURL']}' class='btn btn-primary btn-sm' $disabled>Edit</button> ";
                        echo "<button onclick='confirmDelete({$row_payment['Payment_ID']})' class='btn btn-danger btn-sm' $disabled>Delete</button>";
                        echo "</td>";
                
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No transactions found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <br>

    <?php if ($details && $details['Status'] != 2): ?>
    <button id="new-payment-button" class="btn btn-success">New Payment</button>
<?php else: ?>
    <button id="new-payment-button" class="btn btn-success" disabled>New Payment</button>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const status = <?= json_encode($details['Status']) ?>;
    const balance = <?= json_encode($details['Balance']) ?>;
    const newPaymentButton = document.getElementById('new-payment-button');

    if (status == 2) {
        Swal.fire({
            title: 'Notice',
            text: 'New payments are currently unavailable because your placement status is inactive.',
            icon: 'info',
            confirmButtonText: 'OK'
        });
        newPaymentButton.disabled = true;
    }

    if (balance == 0) {
        Swal.fire({
            title: 'Congratulations!',
            text: 'You have completed all payments.',
            icon: 'success',
            confirmButtonText: 'OK'
        });
        newPaymentButton.disabled = true;
    }
});

function confirmDelete(paymentId) {
    Swal.fire({
        title: 'Are you sure?',
        text: 'Do you want to delete this payment?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `delete_payment.php?payment_id=${paymentId}`;
        }
    });
}
</script>

<div class="new-payment-form p-3" id="new-payment-form">
    <h2>New Payment</h2>
    <form action="submit_payment.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="placement_id" value="<?php echo htmlspecialchars($placement_id); ?>">

        <label for="description">Description:</label>
        <select id="description" name="description" required>
            <option value="" disabled selected>Select Description</option>
            <?php
            if (isset($placement_duration) && $placement_duration > 0) {
                for ($i = 1; $i <= $placement_duration; $i++) {
                    echo "<option value='Month-$i'>Month-$i</option>";
                }
            } else {
                echo "<option value='' disabled>No valid duration found</option>";
            }
            ?>
        </select>
        
        <label for="amount">Amount:</label>
        <input type="text" id="amount" name="amount" value="130" readonly required>

        <label for="receipt">Receipt:</label>
        <input type="file" id="receipt" name="receipt" accept="image/*" required>

        <button type="submit">Submit Payment</button>
    </form>
</div>

<script>
function openEditModal(button) {
    const paymentId = button.getAttribute('data-id');
    const description = button.getAttribute('data-description');
    const amount = button.getAttribute('data-amount');
    const receiptUrl = button.getAttribute('data-receipt-url');

    document.getElementById('edit-placement-id').value = paymentId;
    document.getElementById('edit-description').value = description;
    document.getElementById('edit-amount').value = amount;
    // Display the existing receipt image
    document.getElementById('edit-form').action = `../student/update_payment.php?payment_id=${paymentId}`;

    $('#editPaymentModal').modal('show');
}

document.getElementById('description').addEventListener('change', function() {
    var amountInput = document.getElementById('amount');
    if (this.value) {
        amountInput.value = '130'; // Set to the desired default value
        amountInput.readOnly = true; // Make the field read-only
    } else {
        amountInput.value = '';  // Reset value
        amountInput.readOnly = false; // Make the field editable again
    }
});
</script>

</div>

<!-- Include Bootstrap CSS and JS for modal functionality -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

<!-- Edit Payment Modal -->
<div class="modal fade" id="editPaymentModal" tabindex="-1" role="dialog" aria-labelledby="editPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editPaymentModalLabel">Edit Payment</h5>
                <button type="button" class="close" onclick="closeEditModal()" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="edit-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="placement_id" id="edit-placement-id">

                    <div class="form-group">
                        <label for="edit-description">Description:</label>
                        <select id="edit-description" name="description" class="form-control" required>
                            <option value="" disabled>Select Description</option>
                            <?php
                            if (isset($placement_duration) && $placement_duration > 0) {
                                for ($i = 1; $i <= $placement_duration; $i++) {
                                    echo "<option value='Month-$i'>Month-$i</option>";
                                }
                            } else {
                                echo "<option value='' disabled>No valid duration found</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="edit-amount">Amount:</label>
                        <input type="text" id="edit-amount" name="amount" class="form-control" required readonly>
                    </div>

                    <div class="form-group">
                        <label for="edit-receipt">Receipt:</label>
                        <input type="file" id="edit-receipt" name="receipt" class="form-control-file" accept="image/*" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Save changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
<?php if (isset($_GET['success']) && $_GET['success'] == 'true'): ?>
Swal.fire({
    title: 'Payment Updated!',
    text: 'Your payment was updated successfully.',
    icon: 'success',
    confirmButtonText: 'OK'
});
<?php endif; ?>

<?php if (isset($_GET['delete_success']) && $_GET['delete_success'] == 'true'): ?>
Swal.fire({
    title: 'Payment Deleted!',
    text: 'Your payment was deleted successfully.',
    icon: 'success',
    confirmButtonText: 'OK'
});
<?php endif; ?>

const newPaymentButton = document.getElementById('new-payment-button');
const newPaymentForm = document.getElementById('new-payment-form');

newPaymentButton.addEventListener('click', () => {
    // Toggle the expanded class to control visibility and transitions
    if (newPaymentForm.classList.contains('expanded')) {
        newPaymentForm.classList.remove('expanded');
        setTimeout(() => newPaymentForm.style.display = 'none', 500); // Hide after transition
    } else {
        newPaymentForm.style.display = 'block'; // Show immediately
        setTimeout(() => newPaymentForm.classList.add('expanded'), 0); // Delay to ensure display block is applied first
    }
});

function closeEditModal() {
    $('#editPaymentModal').modal('hide');
}
</script>

<?php include 'layout/footer.php'; ?>
<?php
}      
?>