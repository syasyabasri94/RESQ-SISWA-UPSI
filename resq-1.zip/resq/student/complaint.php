<?php 
session_start();

$username = $_SESSION['username'];
$userid = $_SESSION['userid'];

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql_details2 = "SELECT * FROM placement WHERE Student_ID = $userid AND Status = 2";
$result_details2 = $conn->query($sql_details2);

if ($result_details2->num_rows > 0) {
    $details2 = $result_details2->fetch_assoc();
}

$sql = "SELECT * FROM `complaint` WHERE `Student_ID` = $userid";
$result = $conn->query($sql);

$complaints = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $complaints[] = $row;
    }
}

?>


<?php include 'layout/header.php'; ?>

<style>
    .content {
        text-align: center;
        padding: 20px;
    }

    .student-complaint-section {
        width: 60%;
        border: 1px solid #ddd;
        padding: 20px;
        background-color: #f9f9f9;
        border-radius: 8px;
        margin-top: 30px;
        margin-left: auto;
        margin-right: auto;
        display: none;
    }

    .student-complaint-section h2 {
        margin-top: 0;
        color: #333;
        font-family: Arial, sans-serif;
    }

    .student-complaint-section label {
        display: block;
        margin-bottom: 10px;
    }

    .student-complaint-section input[type="text"],
    .student-complaint-section textarea,
    .student-complaint-section input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .student-complaint-section button {
        background-color: #5c67f2;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
    }

    .student-complaint-section button:hover {
        background-color: #5058cc;
    }

    .complaints-listing {
        width: 90%;
        margin: 20px auto;
        border-collapse: collapse;
    }

    .complaints-listing th,
    .complaints-listing td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
    }

    .complaints-listing th {
        background-color: #f2f2f2;
        text-align: center;
    }

    .complaints-listing td {
        text-align: center;
    }

    .complaints-listing table {
        margin-left: auto;
        margin-right: auto;
    }

    .new-complaint-button {
        background-color: #28a745;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-top: 20px;
    }

    .new-complaint-button:hover {
        background-color: #218838;
    }

</style>
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
$sql = "SELECT * FROM `placement` WHERE `Student_ID` = $userid AND Status = '1'";
$result2 = $conn->query($sql);

while ($row2 = $result2->fetch_assoc()) {
    $studentid = $row2['Student_ID'];

}
$details2 = isset($details2) ? $details2 : null;

if ($details2){
        ?>
<script>
    // Display SweetAlert for booking a room
    Swal.fire({
        icon: 'warning',
        title: 'Your booking has not been accepted yet',
        text: 'To continue on this page, please wait booking to be accepted.',
        showCancelButton: false,
        confirmButtonText: 'Done',
    }).then((result) => {
        // Redirect to booking page regardless of user's choice
        window.location.href = '../student/room.php';
    });
</script>
<?php
    } else if (empty($studentid)){
        ?>
        <script>
    // Display SweetAlert for booking a room
    Swal.fire({
        icon: 'error',
        title: 'You need to book your room first',
        text: 'To continue on this page, please book your room first.',
        showCancelButton: false,
        confirmButtonText: 'Book Now',
    }).then((result) => {
        // Redirect to booking page regardless of user's choice
        window.location.href = '../student/hostel.php';
    });
</script>
<?php
}  else{      
?>
<div class="content">
    <h1 class="title">Complaint Section</h1>
    
    <!-- Complaints Table -->
    <div class="complaints-listing">
        <h2>Your Complaints</h2>
        <table>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
                <th>Remark</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
            <?php foreach ($complaints as $complaint): ?>
                <tr>
                    <td><?= htmlspecialchars($complaint['Title']) ?></td>
                    <td><?= htmlspecialchars($complaint['Description']) ?></td>
                    <td><?= $complaint['Date'] ? date('Y-m-d', strtotime($complaint['Date'])) : 'N/A' ?></td>
                    <td><?= htmlspecialchars($complaint['Remark']) ?></td>
                    <td><a href="<?= htmlspecialchars($complaint['ImageURL']) ?>" target="_blank">View Image</a></td>
                    <td>
                        <button class="btn btn-danger" <?= !is_null($complaint['Remark']) ? 'disabled' : '' ?> onclick="confirmDelete(<?= $complaint['Complaint_ID'] ?>)">Delete</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <button class="new-complaint-button" onclick="toggleComplaintForm()">New Complaint</button>
    </div>

    <!-- Complaint Submission Form -->
    <div class="student-complaint-section" id="complaintFormSection">
        <h2>Detail of Complaint</h2>
        <form id="complaintForm" enctype="multipart/form-data">
            <label for="title">Title:</label>
            <input type="text" id="title" name="title" required>
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>
            
            <label for="proof">Proof (Image):</label>
            <input type="file" id="proof" name="proof" required>
            
            <button type="submit">Submit Complaint</button> 
        </form>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
function toggleComplaintForm() {
    var formSection = document.getElementById('complaintFormSection');
    if (formSection.style.display === 'none' || formSection.style.display === '') {
        formSection.style.display = 'block';
    } else {
        formSection.style.display = 'none';
    }
}

function confirmDelete(complaintId) {
    swal({
        title: "Are you sure?",
        text: "Do you want to delete this complaint?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            deleteComplaint(complaintId);
        }
    });
}

function deleteComplaint(complaintId) {
    $.ajax({
        type: "POST",
        url: "delete_complaint.php",
        data: { complaint_id: complaintId },
        success: function(response) {
            var result = JSON.parse(response);
            if (result.status === "success") {
                swal("Deleted", result.message, "success").then(function() {
                    location.reload();
                });
            } else {
                swal("Error", result.message, "error");
            }
        },
        error: function(xhr, status, error) {
            swal("Error", "AJAX request failed: " + error, "error");
        }
    });
}

$(document).ready(function() {
    $('#complaintForm').on('submit', function(event) {
        event.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            type: "POST",
            url: "submit_complaint.php",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                var result = JSON.parse(response);
                if (result.status === "success") {
                    swal("Success", result.message, "success").then(function() {
                        location.reload();
                    });
                } else {
                    swal("Error", result.message, "error");
                }
            },
            error: function(xhr, status, error) {
                swal("Error", "AJAX request failed: " + error, "error");
            }
        });
    });
});
</script>

<?php include 'layout/footer.php'; ?>
<?php
}   
?>