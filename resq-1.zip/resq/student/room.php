<?php 
session_start();

$username = $_SESSION['username'];
$userid = $_SESSION['userid'];

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Escape user input
$userid = $conn->real_escape_string($userid);

// Fetch placement data for the logged-in student
$sql_placement = "SELECT * FROM placement WHERE Status != 3 AND Student_ID = '$userid'";
$result_placement = $conn->query($sql_placement);
$placement = $result_placement->fetch_assoc();

// Fetch room details if placement data is found
if ($placement) {
    $room_id = $conn->real_escape_string($placement['Room_ID']);
    
    $sql_room = "SELECT * FROM room WHERE Room_ID = '$room_id'";
    $result_room = $conn->query($sql_room);
    $room = $result_room->fetch_assoc();

    // Fetch hostel name
    if ($room) {
        $hostel_id = $conn->real_escape_string($room['Hostel_ID']);
        
        $sql_hostel = "SELECT Name FROM hostel WHERE Hostel_ID = '$hostel_id'";
        $result_hostel = $conn->query($sql_hostel);
        $hostel = $result_hostel->fetch_assoc();
    }
}

include 'layout/header.php'; 
?>


<style>
    /* General table styles */
    .table-container {
        display: flex;
        justify-content: center;
        width: 100%;
        margin-top: 20px;
        overflow-x: auto; /* Ensures the table is scrollable on small screens */
    }

    table {
        width: 80%; /* Adjust based on preference */
        border-collapse: collapse;
        margin: 0 auto;
        background-color: #f9f9f9; /* Light grey background */
        box-shadow: 0 2px 15px rgba(0,0,0,0.1); /* Subtle shadow for depth */
    }

    th, td {
        border: 1px solid #ddd; /* Lighter border color */
        text-align: left;
        padding: 12px 15px;
        color: #333; /* Dark grey text for better readability */
    }

    th {
        background-color: #ced3c4; /* Blue header background */
        color: white;
        font-weight: bold;
    }

    /* Responsive table headers */
    th[colspan="3"] {
        text-align: center;
    }

    /* Row styles for alternating background */
    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    /* Styling for hostel names to make them stand out */
    .hostel-name {
        font-weight: bold;
        color: #444641; /* Darker blue for emphasis */
    }
    .title {
        text-align: center; /* Centers the title */
        margin-top: 0;
        color: #444641; /* Same color as the table text for consistency */
    }

    /* Pay Now button styling */
    .pay-now-btn {
        display: inline-block;
        background-color: #28a745; /* Green background */
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        border-radius: 5px;
        margin-top: 20px;
        font-size: 16px;
        font-weight: bold;
    }

    .button-container {
        text-align: right; /* Aligns the button to the right */
        width: 80%; /* Same width as the table */
        margin: 0 auto; /* Center container within the page */
        margin-top: 10px;
        margin-bottom: 10px;
    }
</style>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php
    if (empty($placement)){
        ?>
        <script>
    // Display SweetAlert for booking a room
    Swal.fire({
        icon: 'error',
        title: 'You need to book your room first',
        text: 'To continue on this page, please book your room first.',
        showCancelButton: false,
        confirmButtonText: 'Book Now',
    }).then((result) => {
        // Redirect to booking page regardless of user's choice
        window.location.href = '../student/hostel.php';
    });
</script>
        <?php   
    } else {
        ?>
        <div class="content">
<?php if($placement['Status'] == 2): ?>
    <div style="width: 80%; margin: 0 auto;">
        <li class="alert alert-info">
            Your booking is pending approval from our staff. You can cancel the booking if you want to change rooms.
        </li>
    </div>
<?php endif; ?>
    <h1 class="title">Room Details</h1>

    <div class="table-container">
        <table>
            <tr>
                <th colspan="3" style="font-size: 20px;">Room Related Information</th>
            </tr>
            <tr>
                <td colspan="3" style="color: #444641; font-weight: bold;">Register no: <?php echo $userid; ?></td>
            </tr>
            <tr>
                <td rowspan="4" class="hostel-name">Hostel</td>
                <td style="color: #444641; font-weight: bold;">Blok: <?php echo isset($hostel) ? $hostel['Name'] : 'N/A'; ?></td>
            </tr>
            <tr>
                <td style="color: #444641; font-weight: bold;">Floor: <?php echo isset($room) ? $room['Floor'] : 'N/A'; ?></td>
            </tr>
            <tr>
                <td style="color: #444641; font-weight: bold;">House: <?php echo isset($room) ? $room['House_No'] : 'N/A'; ?></td>
            </tr>
            <tr>
                <td style="color: #444641; font-weight: bold;">Room: <?php echo isset($room) ? $room['Room_Name'] : 'N/A'; ?></td>
            </tr>
            <tr>
                <td rowspan="3" class="hostel-name">Fee</td>
                <td style="color: #444641; font-weight: bold;">Fee Per Month: RM 130</td>
            </tr>
            <tr>
                <td style="color: #444641; font-weight: bold;">Total Paid: RM <?php echo isset($placement) ? $placement['Total'] : '0'; ?></td>
            </tr>
            <tr>
                <td style="color: #444641; font-weight: bold;">Balance: RM <?php echo isset($placement) ? $placement['Balance'] : '0'; ?></td>
            </tr>

        </table>
    </div>
</div>

<div class="button-container">
    <?php 
    if($placement['Status'] == 2){
    ?>
        <a href="#" class="btn btn-danger" onclick="cancelBooking(<?php echo $placement['Placement_ID']; ?>)">Cancel Booking</a>
    <?php 
    }else{
        ?>
        <a href="../student/payment.php" class="btn btn-success">Pay Now</a>
        <?php 
    }
    ?> 
</div> 
<br>
        <?php     
    }
?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    function cancelBooking(placementId) {
        Swal.fire({
            title: 'Are you sure?',
            text: 'You are about to cancel your booking. This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, cancel it'
        }).then((result) => {
            if (result.isConfirmed) {
                // User confirmed, send AJAX request to delete the booking
                $.ajax({
                    url: '../student/cancel_booking.php',
                    type: 'POST',
                    data: { placementId: placementId },
                    success: function(response) {
    console.log('Booking cancelled successfully');
    // Show success message
    Swal.fire('Booking Cancelled!', '', 'success').then((result) => {
        // Redirect to room.php
        window.location.href = '../student/room.php';
    });
},
                    error: function(xhr, status, error) {
                        // Show error message
                        Swal.fire('Error!', 'Failed to cancel booking.', 'error');
                    }
                });
            }
        });
    }
</script>

<?php include 'layout/footer.php'; ?>
