<?php
session_start();

// Database connection settings
require '../mysqlconnection.php';
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['complaintID'])) {
    $complaintID = intval($_POST['complaintID']); // Ensure the input is an integer

    // Prepare and execute query
    $sql = "SELECT * FROM `complaint` WHERE `ComplaintID` = $complaintID";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $complaint = $result->fetch_assoc();
        echo json_encode($complaint);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Complaint not found']);
    }

} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}

$conn->close();
?>
